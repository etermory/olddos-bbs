inherit MONSTER;

int environment_check();
void monster_chat();

void heart_beat() {

	continue_attack();
	if(random(100)+1 < query("�̾߱�Ȯ��"))  monster_chat();
	unblock_attack();
	if( environment_check() ) return;
	if( sizeof(attackers) ) return;
	if(query("ü��") == query("�ִ�ü��")) {
		set_heart_beat(0);
		hb_status = 0;
	}
}

void monster_chat() {
	mixed *chats;

	if(attackers && sizeof(attackers))  chats = query("�������̾߱�");
	else  chats = query("�̾߱�");

	if(!chats || !sizeof(chats))  return ;

	if(environment())
		tell_room(environment(), chats[ random(sizeof(chats)) ]);

	return; 
}
