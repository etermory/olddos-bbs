#include <config.h>

void clean_up() { destruct(this_object()); }

void create() { seteuid(getuid(this_object())); }

int query_prevent_shadow() { return (1); }
