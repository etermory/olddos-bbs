#include <config.h>
#include <mudlib.h>
#include <daemons.h>
#include <logs.h>
#include <priv.h>
#include <uid.h>
#include <move.h>
#include <commands.h>
#include <messages.h>
#include <ansi.h>

inherit "/std/body/attack.c" ;
inherit "/std/body/alias.c" ;
inherit "/std/body/wild_card.c" ;
inherit "/std/body/more.c" ;

static nomask object link ;

private string __Term;
static private mapping __TermInfo;

void set_term(string str);
string query_term();
void basic_commands() ;
mixed query_env (string env);
static void init_commands();

nomask object query_link() { 
	return link;
}

void set_link(object ob) {
	if (geteuid(previous_object()) != ROOT_UID && 
			base_name(previous_object()) != CONNECTION)  return;
	link = ob;
}

nomask mixed link_data(string what) {
	if (!link) return 0;
	return (mixed)link->query(what);
}

void debug(string mess) {
#ifdef DEBUG
	message(MSG_DEBUG, mess, this_player());
#endif
}

int force_me(string cmd) {
	string tmp, verb;
	int res;

	if (previous_object()) tmp = geteuid(previous_object()) ;
	else tmp = geteuid(this_object()) ;

	if(tmp != ROOT_UID && tmp != geteuid(this_object())) return 0;

	if(interactive(this_object()))
		cmd = (string)this_object()->process_input(cmd);

	verb = explode(cmd, " ")[0];
	res = command(cmd);

	return res;
}

void init_setup() {

	set_living_name( query("�̸�") );
	seteuid( getuid(this_object()) );
	set( "���̵�", ({ query("�̸�") }) );
	set( "������", query_ip_name(this_object()) );
	set("�Ѻ���", 500) ;
	set("�ѹ���", 5000) ;
	set("����2",0) ;
	set("��������",0) ;
	set("������",0) ;
	set("��", ([]) ) ;
	set("�޼�������", "", OWNER_ONLY);
	set("�����÷���", 0, READ_ONLY);
	delete("����������");
	set_heart_beat(1);
	basic_commands();
	init_commands();
	this_object()->load_autoload_obj();
}

void enable_me() {
	if (geteuid(previous_object()) != ROOT_UID) return ;
	enable_wizard() ;
}

void receive_message(string Class, string msg) {

	if((int)query("����")) {
		this_object()->relay_message(Class, msg);
		return;
	}

	if(query("����/����")) {
		if( Class == "��������" ) return ;
	}

	if (this_player() && this_object() != this_player()) {
		if((int)this_player()->query("����") == 1 && !wizardp(this_object())) return;
		if((int)this_player()->query("����") == 2 && !adminp(geteuid(this_object()))) return;
	}

	msg = terminal_colour(msg,TERMINAL_D->query_term_info("VT100"));

	if(this_object()->getenv("enable_buffer") && query("�����÷���") && Class!=MSG_UNKNOWN) {
		ob_data["�޼�������"] = ob_data["�޼�������"] + msg;
		return;
	}
	receive(msg);     
	return;
}

void receive_snoop (string str) {
	receive(":" + str);
}

void catch_tell(string msg) { receive_message(MSG_UNKNOWN,msg); }

int dump_buffer() {
	string *dump, output;

	if(geteuid(previous_object()) != geteuid(this_object()))  return 0;

	output = query("�޼�������");
	set("�����÷���", 0);

	if(!output || output == "") return 0;

	write("DUMP:"+dump_variable(output));
	dump = ({ "\n" + bold("[Queued message buffer output]") }) +
		explode(output, "\n");

	this_object()->more(dump);
	set("�޼�������", "");

	return 1; 
}

void net_dead() {
	if (userp(this_object())) {
		this_object()->save_data();
	} 
	set_heart_beat(0);
#ifdef NETDEAD_LOG
	log_file(NETDEAD_LOG, query("�̸�") + ": net-dead\t\t" + 
			ctime(time()) + " from " + query("������") + "\n");
#endif
	link->remove();
}

void restart_heart() {
	message(MSG_MOVEMENT, query("�̸�")+" has reconnected.\n", environment(),
			this_object());
	message(MSG_MOVEMENT, "Reconnected.\n", this_object());
	set_heart_beat(1);
}

string local_commands() { 
	mixed *cmds;
	int i;
	string result;

	if(geteuid(previous_object()) != ROOT_UID &&
			!adminp(geteuid(previous_object())))
		return "You aren't authorized to check this information.\n";

	cmds = commands();

	if (!sizeof(cmds)) return "No commands available";

	result = "";
	while (i < sizeof(cmds)) {
		result += (cmds[i][0] + " ");
		i++;
	}

	return result + "\n";
}

mixed *user_commands() { return commands(); }

void set_term(string str) {
	__TermInfo = (mapping)TERMINAL_D->query_term_info(__Term = str);
}

string query_term() { return __Term; }
