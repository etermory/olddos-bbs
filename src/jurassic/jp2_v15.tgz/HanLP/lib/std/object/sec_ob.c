inherit "std/object/ob";
#define SECURE
