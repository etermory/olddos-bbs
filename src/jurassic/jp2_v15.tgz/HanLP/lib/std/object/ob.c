#include "/std/object/prop.c"
#include <mudlib.h>
#include <uid.h>
#include <move.h>

mixed query(string what);
varargs int set(string what, mixed value, int access_level);
int remove();
int move(mixed dest);
void add(string what, mixed arg);
varargs void delete(string what, mixed arg);
string query_short() { return query("ª������"); }

int id(string str) {
    string *ids;
    ids = query("���̵�");
    if (!pointerp(ids) || !ids) return 0;
    if(!stringp(str)) return 0;
    if(member_array(str, ids) != -1) return 1;
}

int move(mixed dest) {
    object ob;
    string err;
    int bulk, mass;

    bulk = query("����");
    mass = query("����") ;
    if (stringp(dest)) {
	ob = find_object(dest);
	if (!ob) { 
	    dest = resolv_path("cwd", dest);
	    err = catch(call_other(dest, "???"));
	    if (err) { 
		write(err + "\n"); 
		return MOVE_NO_DEST;
	    }
	    ob = find_object(dest);
	}
    }   
    else ob = dest;

    if(environment() && !environment()->release_object(this_object()))
	return MOVE_NOT_ALLOWED;

    if (!ob || !ob->receive_object(this_object()))
	return MOVE_NOT_ALLOWED;

    if (living(this_object()) && living(ob) && !((int)ob->move_ok()))
	return MOVE_NOT_ALLOWED;

    if (environment(this_object()) == ob)
	return MOVE_NOT_ALLOWED;

    if (ob->query("�Ѻ���") < (int)query("����"))
	return MOVE_NO_ROOM;

    if (ob->query("�ѹ���") < (int)query("����"))
	return MOVE_TOO_HEAVY ;

    if (environment()) {
	environment()->add("�Ѻ���", bulk);
	environment()->add("�ѹ���", mass) ;
    }
    set("�������", environment());
    move_object(ob);
    ob->add("�Ѻ���", -bulk);
    ob->add("�ѹ���", -mass) ;
    return MOVE_OK;
}

int remove() {

    object super;
    int i, res ;
    object *ob_list;

    super = environment(this_object());
    if (super) {
	super->add("�Ѻ���", query("����"));
	super->add("�ѹ���", query("����")) ;
	ob_list = all_inventory(this_object());
	for (i=0; i < sizeof(ob_list); i++) {
	    res = ob_list[i]->move(super);
	    if (res!=MOVE_OK) {
		write ("An object vanishes. Tell a wiz!\n") ;
	    }
	}
    }
    destruct(this_object());
    return 1;
}

int clean_up(int inherited) {
    object env, *contents;
    int i;

    if (inherited)  return 0;
    if (userp(this_object())) return 0;
    env = environment();
    if (env && userp(env)) return 1;
    if (env && environment(env)) 
	return (int)environment(env)->clean_up();
    contents = deep_inventory(this_object());
    if (contents) {
	for (i=0;i<sizeof(contents);i++)
	    if (userp(contents[i])) return 1;
    }
    if (!env) {
	if (!inherits(ROOM, this_object()) && !clonep(this_object()) 
		&& (file_name(this_object())[0..4] == "/std/"))
	    return 0;

	remove();
	return 1;
    }
    return 1;
}

int receive_object(object foo) {
    return 1;
}

int release_object(object foo) {
    return 1;
}

int check_light() {

    int i ;
    object *obs ;

    if (query("light")) return 1 ;

    obs = all_inventory(this_object()) ;
    if (!obs) return 0 ;

    if (query("opaque")) return 0 ;

    for (i=0;i<sizeof(obs);i++) {
	if (obs[i]->check_light()) return 1 ;
    }
    return 0 ;
}
