mapping ob_data;
static mapping tmp_ob_data;

#include <uid.h>
#include "/std/object/prop_logic.c"

void init_ob() {
				if( !ob_data ) ob_data = ([]);
				if( !tmp_ob_data ) tmp_ob_data = ([]);
}

mapping query_ob_data() { 
				if(!adminp(geteuid(previous_object())) &&
												geteuid(previous_object()) != ROOT_UID)  return 0;
				return ob_data;
}

mapping query_temp_ob_data() {
				if(!adminp(geteuid(previous_object())) &&
												geteuid(previous_object()) != ROOT_UID)  return 0;
				return tmp_ob_data;
}

nomask varargs int set( string label, mixed value, int access_level ) {
				if( !ob_data ) init_ob();
				if( !label ) return 0;
				if(label[<1]=='/') return 0;
				while( label[0] == '/' && strlen(label) > 1 )
								label = label[1..<1];
				_set( ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}), value );
				return 1;
}

varargs int set_temp( string label, mixed value, int access_level ) {
				if( !tmp_ob_data ) init_ob();
				if( !label ) return 0;
				_set( tmp_ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}), value );
				return 1;
}

varargs void delete( string label ) {
				if( !ob_data ) init_ob();
				if( !label ) return 0;
				_delete( ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}) );
}

varargs void delete_temp( string label ) {
				if( !label ) return 0;
				if( !tmp_ob_data ) init_ob();
				_delete( tmp_ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}) );
}

nomask mixed query( string label ) {
				mixed value;
				string func, arg;

				if( !ob_data ) init_ob();
				if( !label ) return 0;
				value = _query( ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}) );
				if( stringp( value ) && sscanf( value, "@@%s", func ) ) {
								if (func[0..5]!="query_") return 0 ;
								if( sscanf( func, "%s:%s", func, arg ) )
												return call_other( this_object(), func, arg );
								else
												return call_other( this_object(), func );
				}
				return value;
}

nomask mixed query_temp( string label ) {
				mixed value;
				string func, arg;

				if( !tmp_ob_data ) init_ob();
				if( !label ) return 0;
				value = _query( tmp_ob_data, strsrch(label,"/")!=-1?explode(label,"/"):({label}) );
				if( stringp( value ) && sscanf( value, "@@%s", func ) ) {
								if( sscanf( func, "%s:%s", func, arg ) )
												return call_other( this_object(), func, arg );
								else
												return call_other( this_object(), func );
				}
				return value;
}

void add( string label, mixed arg ) {
				mixed foo;
				foo = query( label );
				if( !foo ) set( label, arg );
				else set( label, foo + arg );
				return;
}

void add_temp( string label, mixed arg ) {
				mixed foo;
				foo = query_temp( label );
				if( !foo ) set_temp( label, arg );
				else set_temp( label, foo + arg );
				return;
}
