private int bitflags;

void set_flag(int n) {   bitflags |= n; }

int test_flag(int n) {   return bitflags & n; }

void clear_flag(int n) {   bitflags &= ~(n); }
