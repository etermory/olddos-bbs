string do_alias(string arg);

string write_prompt(int num)
{
	string prompt;
	int mhp, hp, msp, sp;

	mhp = this_object()->query("�ִ�ü��");
	msp = this_object()->query("�ִ����ŷ�");
	hp = this_object()->query("ü��");
	sp = this_object()->query("���ŷ�");

	prompt = "[ "+hp+"/"+mhp+","+sp+"/"+msp+" ]\n";

	if( num ) return prompt;
	tell_object(this_object(),prompt);
	return "";
}

static nomask string process_input(string arg)
{
	int x;
	string fm;

	x = strlen(arg);
	fm = arg[x-1..];

	if( fm == "." || fm == "?" || fm  == " ") return arg+" ��";
	else if( arg == "!" ) return this_object()->query_temp("��������");
	else {
		arg = do_alias(arg);
		if( arg && arg != "" )
			this_player()->set_temp("��������",arg);
		return arg;
	}
}
