#include <uid.h>

private mixed *auto_load;

void load_autoload_obj()
{
    string file;
    mixed item, argument;
    object ob;
    int j, limit;

    limit = (auto_load) ? sizeof(auto_load) : 0;
    for (j = 0; j < limit; j++) {
	item = auto_load[j];
	argument = 0;
	if (stringp(item))
	    sscanf(item, "%s:%s", file, argument);
	else if (pointerp(item) && (sizeof(item) == 2)) {
	    file = (string)item[0];
	    argument = (mixed *)item[1];
	}
	else
	    continue;
	if (file) {
	    if (file_size(file + ".c") <= 0 ||
		    catch(call_other(file, "?")) ||
		    catch(ob=clone_object(file))) {
		ob = 0;
		write(file+" : ã�� �� �����ϴ�.\n");
	    }
	    if (ob) {
		if (argument)
		    call_other(ob, "init_arg", argument);
		ob->move(this_object());
	    }
	}
    }
}

void compute_autoload_array()
{
    object *inv, ob;
    mixed item;
    int j, ok;

    auto_load = ({});
    inv = all_inventory(this_object());
    for (j = 0; j < sizeof(inv); j++) 
    {
	ob = inv[j];
	item = (mixed)call_other(ob, "query_auto_load");
	ok = 0;
	if (pointerp(item)) {
	    if ((sizeof(item) == 2) && stringp(item[0]))
		ok = 1;
	}
	else if (stringp(item))
	    ok = 1;
	else
	    item = 1;
	if (!ok && item) {
	    sscanf(file_name(ob), "%s#%*d", item);
	    item += ":";
	}
	if (item)
	    auto_load += ({ item });
    }
}

void destroy_autoload_obj()
{
    object *inv;
    int j;

    inv = all_inventory(this_object());
    for (j = 0; j < sizeof(inv); j++)
	inv[j]->remove();
}

mixed *query_autoload_array() {
    if(!adminp(geteuid(previous_object())) &&
	    geteuid(previous_object()) != ROOT_UID)  return 0;
    return auto_load;  
}
