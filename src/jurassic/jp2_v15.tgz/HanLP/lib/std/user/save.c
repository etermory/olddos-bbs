#include <uid.h>
#include <config.h>

nomask int restore_body() {
    if (base_name(previous_object()) != CONNECTION &&
	    getuid(previous_object()) != ROOT_UID)  return 0;
    seteuid(geteuid(previous_object()));
    if (!geteuid())  return 0;
    return restore_object(user_data_file(this_object()));
}

nomask void save_data() {
    string euid;

    euid = geteuid();

    if (!euid) seteuid(getuid());
    if (!euid || euid == "Logon" || euid == ROOT_UID) return;

    this_object()->compute_autoload_array(); /* Tru - 92/02/11 */

    assure_user_save_dir(this_object());
    save_object(user_data_file(this_object()));
}

nomask void save_room(string str) {
    string euid;

    euid = geteuid();
    save_object(str);
}

    void save_player(string name) {
	if (previous_object())
	    log_file("save_player", file_name(previous_object()) + "\\n");
	save_data();
    }

    nomask void save_me() { 
	save_data();
    }
