#include <config.h>

private static int persistent;

static void set_persistent(int which)
{
	persistent = which;
}

void save_data()
{
	string base;

	base = data_dir(this_object());
	if (!directory_exists(base)) {
		MASTER_OB->make_data_dir();
	}
	save_object(data_file(this_object()));
}

int restore_data()
{
	string file;

	file = data_file(this_object());
	if (file_exists(file + __SAVE_EXTENSION__)) 
	{
		return restore_object(data_file(this_object()));
	} 
	else 
	{
		return 0;
	}
}

void remove()
{
	if (persistent) 
	{
		save_data();
	}
	destruct(this_object());
}

void create()
{
	restore_data();
}
