#include <uid.h>
#include <login.h>
#include <daemons.h>
#include <config.h>
#include <origin.h>

string name, password, body, email, real_name, ip, userid;
mapping domains;
mixed *passwd_fail;
int wizard, last_on, dead, hibernate;

static object body_ob, tmp_body;
static string termtype;
private static int height, width;
private static int port;

int remove();
int save_data_conn();
static void terminal_type(string term);

int query_prevent_shadow() {  return 1;  }

static void logon( int logonport) {
	seteuid(0);
	wizard = 0;
	termtype = "UNKNOWN";
	height=24; width=80;
	port=logonport;
	call_out("check_status", 5 * 60);
	LOGIN_D->logon(this_object());
	return;
}

int connect() {
	if (geteuid(previous_object()) != ROOT_UID) return 0;
	if (!body_ob) return 0;
	if (!interactive(this_object())) {
		if (!interactive(body_ob)) body_ob->remove();
		remove();
	} 

	if (!exec(body_ob, this_object())) {
		write("Error connecting to your body... try again...\n");
		body_ob->remove();
		remove();
		return 0;
	}
	body_ob->set_link(this_object());
	return 1;
}

nomask void receive_message(string Class, string msg) { receive(msg); }
nomask void catch_tell(string msg) { receive(msg); }

void link_dead() { 
	if (!name || name == "������" || !password) {
		delete_ip_check(query_ip_number(this_object()));
	}
	save_data_conn(); 
	remove(); 
}

object query_link() { return this_object() ; }

int save_data_conn() {

	mixed *dir;

	if (!name || name == "������" || !password) return 0;
	dir = get_dir(UDATA_DIR(name));
	if(!dir || !sizeof(dir)) mkdirs(UDATA_DIR(name));
	save_object(PDATA_FILE(name));
	return 1;
}

int restore() {
	if( !name ) return 0;
	return restore_object(PDATA_FILE(name));
}

int restore_body() {
	if (geteuid(previous_object()) != ROOT_UID) return 0;
	if (!name || !body) return 0;
	seteuid(name);
	if(catch( body_ob = new(body) ))  return 0;
	export_uid(body_ob);
	if (!body_ob) return 0;
	return (int) body_ob->restore_body();
}

int remove() {
	save_data_conn();
	destruct(this_object());
	return 1;
}

int remove_user() {  call_out("remove", 0);  return 1;  }

int clean_up() {
	if (!body_ob || !interactive(body_ob)) return remove();
	save_data_conn();
	return 1;
}

nomask mixed query(string what) {

	if (!what) return 0;
	switch (what) {
		case "�̸�" :
			return (name ? name : "������");
		case "�̸�" :
			return (name ? name :"������");
		case "password" : return password;
		case "���" : return wizard;
		case "body" : return body;
		case "dead" : return dead;
		case "tmp_body" : return tmp_body;
		case "hibernate" : return hibernate;
		case "real_name" : return real_name;
		case "passwd_fail" : return passwd_fail;
		case "email" : return email;
		case "body_ob" : return body_ob;
		case "last_on" : return last_on;
		case "������" : return ip;
		case "�͹̳�" : return termtype;
		case "height" : return height;
		case "width" : return width;
		case "port" : return port;
		case "userid" : {
			if(geteuid(previous_object()) != ROOT_UID) return 0;
			else return userid;
		}
		case "domains" : {
			if (geteuid(previous_object()) == ROOT_UID)
			{

				return domains;
			}
			else return copy(domains);
		}
		default : return 0;
	}
}

nomask void set(string what, mixed val) {
	if (!what) return 0;

	switch (what) {
		case "�̸�" : name = val; seteuid(name); break;
		case "password" : password = val; break;
		case "���" : wizard = val; break;
		case "passwd_fail" : passwd_fail = val; break;
		case "body" : body = val; break;
		case "tmp_body" : tmp_body = val; break;
		case "real_name" : real_name = val; break;
		case "email" : email = val; break;
		case "body_ob" : body_ob = val; break;
		case "hibernate" : hibernate = val; break;
		case "dead" : dead = val; break;
		case "domains" : domains = val; break;
		case "userid" : userid = val; break;
		case "last_on" : last_on = val; break;
		case "������" : ip = val; break;
		case "�͹̳�" : termtype = val; break;
		case "height": height = val; break;
		case "width": width = val; break;
		case "port": port = val; break;
		default : return;
	}
	save_data_conn();
}

int check_status() {

	remove_call_out("check_status");

	if(interactive(this_object()) || !body_ob || !interactive(body_ob))
		remove();

	return 1; 
}

void terminal_type(string term) {

	termtype = term;
}

static void window_size(int w, int h) {
	if(!h) h = 24;
	if(!w) w = 80;

	if ( ( w < h ) && ( w <25) ) {
		int tmp;
		w = tmp;
		w = h;
		h = tmp;
	}
	height = h;
	width = w;
}
