#include <config.h>
#include <mudlib.h>
#include <daemons.h>
#include <priv.h>

inherit OBJECT ;
inherit "std/object/contents";

void reset();

void __INIT() { if (!ob_data) ob_data = ([]); }

void create() {
	string roomname, tmp1, tmp2;
	int tmp3;

	__INIT();
	set("�Ѻ���", 10000000, MASTER_ONLY);
	set("�ѹ���", 10000000, MASTER_ONLY);
	roomname = file_name(this_object());
	set("�����̸�",roomname);
	if( sscanf(roomname,"/d/%s/%s",tmp1,tmp2) == 2 ||
			sscanf(roomname,"/d/%s/%d",tmp1,tmp3) == 2 ) {
		set("����",tmp1);
	}
}

string *query_exit_dirs() { return keys(ob_data["�ⱸ"]); }
int valid_exit(string dir) {
	if (ob_data["�ⱸ"] && ob_data["�ⱸ"][dir]) return 1; 
	if (ob_data["��й�"] && ob_data["��й�"][dir]) return 1; 
}

int id(string str) {
	if (!str) return 0;
	if (ob_data["�����ۼ���"] && ob_data["�����ۼ���"][str]) 
		return 1;
	if (ob_data["�������Լ�"] && ob_data["�������Լ�"][str]) 
		return 1;
}

void reset() {
	int i, j, k, tally;
	string name;
	object* inv;
	object ob;
	string *objects;

	if (ob_data["������Ʈ"]) {
		objects = keys(ob_data["������Ʈ"]);
		i = sizeof(objects); while(i--){
			if(!intp(ob_data["������Ʈ"][objects[i]])){
				if(!present(objects[i],this_object())){
					ob = new(ob_data["������Ʈ"][objects[i]]);
					ob->move(this_object());
				}
			}else{
				name =((string*)find_object_or_load(objects[i])->query("���̵�"))[0];
				if(!name) continue;
				inv = all_inventory(this_object());
				j = sizeof(inv);
				tally = 0;
				while(j--)
					if(inv[j]->id(name)) tally++;
				k = ob_data["������Ʈ"][objects[i]];
				k = k-tally;
				for(j=0;j<k;j++){
					ob = clone_object(objects[i]);
					ob->move(this_object());
				}
			}
		}
	}
	return;
}

int receive_objects(object it) { return 1; }
int add_encumbrance(int x) { return 1; }

void remove_exit(string dir) {
	if(ob_data["�ⱸ"][dir]) delete("�ⱸ/" + dir);
}

varargs void set_outside (string zone) {
	if (!zone) zone="����" ;
	set ("�ܺ�", zone) ;
	set ("���", "@@query_ambient_light") ;
	seteuid(getuid()) ;
	WEATHER_D->request_weather_notices(this_object()) ;
	return ;
}

int query_ambient_light() {
	return (int)WEATHER_D->query_ambient_light() ;
}
