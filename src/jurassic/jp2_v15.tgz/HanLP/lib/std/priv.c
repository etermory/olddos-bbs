#include <uid.h>
#include <priv.h>

private mapping perms;

static nomask int check_access(mixed what);
nomask int set_access(mixed what, int new_access);
nomask int delete_access(string entry);

void debug(string str) {
#ifdef DEBUG
	write(str + "\n");
#endif
}

void init_access() {
	if(!mapp(perms)) perms = ([ ]);
}

static nomask int check_access(string tmp) {
	int i;
	string *parts;

	debug("Passed to check_access: " + tmp);
	init_access();
	debug("past init_access()");
	if (perms[tmp]) return perms[tmp];
	parts = explode(tmp, "/");

	if (sizeof(parts) == 1) {
		if (file_name(this_object()) == "adm/newaccess")
			return MASTER_ONLY;
		else return PUBLIC;
	}
	if (tmp=="/") return MASTER_ONLY;

	for (i=sizeof(parts)-1;i>=0;i--) {
		tmp = implode(parts[0..i], "/");
		debug("debug: checking for an entry for " + tmp);
		if(perms[tmp]) {
			debug("Matched " + implode(parts, "/") + " with " + tmp);
			return perms[tmp];
		}
	}
	debug("No match, returning PUBLIC status.");
	return PUBLIC;
}

nomask int set_access(string entry, int new_access) {
	string eff_user;
	int curr_access;

	if (!previous_object()) eff_user = geteuid();
	else eff_user = geteuid(previous_object());

#ifdef DEBUG
	write(eff_user + " is trying to change access " + entry + " to " +
			new_access + " for " + file_name(this_object()) + "\n");
#endif

	if (eff_user != geteuid(this_object()) && eff_user != ROOT_UID)
		return 0;

	curr_access = check_access(entry);
	if(!intp(curr_access))  curr_access = 0;

	switch(curr_access) {
		case PUBLIC:
		case READ_ONLY:
		case OWNER_ONLY:
			perms[entry] = new_access;
			return 1;
			break;
		case LOCKED:
		case PRIVATE:
			return 0;
			break;
		case MASTER_ONLY:
			if (eff_user == ROOT_UID) {
				perms[entry] = new_access;
				return 1;
			}
			return 0;
			break;
		default: 
			perms[entry] = new_access;
			return 1;
			break;
	}
}

nomask int delete_access(string entry)
{
	string eff_user;

	eff_user = ( previous_object() ? geteuid( previous_object() ) : geteuid() );
	if( eff_user != geteuid() && eff_user != ROOT_UID ) return 0;

	map_delete( perms, entry );
}

nomask int valid_write(string what, object act_ob) {
	string eff_user;
	int security;

	if (!what) return 0;
	if (!act_ob) act_ob = previous_object();
	if (!act_ob) act_ob = this_player();
	if (!act_ob) { 
		log_file("odd_errors", "no act_ob, /std/priv.c line 149");
		return 0;
	}
	eff_user = geteuid(act_ob);
	security = check_access(what);
	if(!intp(security))  security = 0;
	switch (security) {
		case PUBLIC :
			return 1; break;
		case READ_ONLY :
		case OWNER_ONLY :
			if (eff_user != geteuid() && eff_user != ROOT_UID)
				return 0; break;
		case MASTER_ONLY :
		case LOCKED :
		case PRIVATE :
			if (eff_user != ROOT_UID) return 0; break;
		default : debug("default case reached."); return 0; break;
	}
	return 1;
}

nomask int valid_read(string what, object act_ob) { 
	string eff_user;
	int security;

	if (!act_ob) return 0;
	eff_user = geteuid(act_ob);
	security = check_access(what);
	if(!intp(security))  security = 0;
	switch (security) {
		case PUBLIC :
		case READ_ONLY :
		case MASTER_ONLY :
		case LOCKED :
			return 1; break;
		case OWNER_ONLY :
		case PRIVATE :
			if (eff_user != geteuid() && eff_user != ROOT_UID)
				return 0; break;
		default : debug("default case reached."); return 0; break;
	}
	return 1;
}

int query_permission(string prop) { return check_access(prop); }
