#include <config.h>
#include <mudlib.h>

inherit SECURE_OBJECT;

varargs mixed set(string prop, mixed arg, mixed security) ;
static object *attackers, target, *will_attack;
static int any_attack ;
mixed link_data(string what);

static string qs ;
private static int heal_time ;

static string *vb, *vb2 ;
static int dmin, dmax, damage ;
static string weapontype ;
static int skill_improve_prob ;

int kill_ob (object victim) ;
void set_verbs(string *verbs) ;
void set_verbs2 (string *verbs) ;
string *get_verb() ;
void cease_all_attacks();
void continue_attack() ;
string write_prompt(int silent);

int damage_ch(int damage, object target) {
	if( damage < 5 ) damage = random(5)+1;
	return damage;
}

int receive_damage(int damage, object th) {
	int dam;

	set ("����������",th) ;
	if(damage < 1 || query_temp("���") || query("ü��") < 0 || query("��������"))  return 0;
	dam = query("ü��") - damage;
	set("ü��", dam);
	if(dam < 0) this_object()->die(); 
	return 1; 
}

int receive_healing(int healing) {
	int heal;

	if(healing <= 0 || link_data("���") || query("ü��") < 0) return 0;
	heal = query("ü��") + healing ;
	if(heal > query("�ִ�ü��"))  heal = query("�ִ�ü��");
	set("ü��", heal);
	if( heal < 0 ) {
		this_object()->die();
	}
	return 1; 
}

int calc_armor_class() {

	mapping armor ;
	int ac ;
	string *types ;
	int i ;

	armor = query("��") ;
	if (!armor) {
		set ("������", 0) ;
		return 0 ;
	}
	ac = 0 ;
	types = keys(armor) ;
	for (i=0;i<sizeof(types);i++) {
		ac = ac + armor[types[i]] ;
	}
	set ("������", ac) ;
	return ac ;
}

void block_attack (int t) {

	int i ;

	i = query("�ٻۻ���") ;
	set ("�ٻۻ���",i+t/2) ;
}

void unblock_attack() {

	int i ;

	i = query("�ٻۻ���")-1 ;
	if (i>-1) set ("�ٻۻ���",i) ;
}

int player_busy() {
	return query("�ٻۻ���") ;
}

void init_attack() {
	attackers = ({});
}

object query_attacker() {
	if(!attackers || !sizeof(attackers))  return 0;
	return attackers[0] ;
}

int kill_ob (object victim) {
	int i;

	if(query("��������"))  return 0;

	if (!attackers) {
		init_attack() ;
		attackers = ({ victim }) + attackers;
		any_attack = 1;
		set_heart_beat(1) ;
		victim->kill_ob(this_object());
		return 1;
	}

	i = member_array(victim, attackers);

	if (i > -1) {
		return 0;
	}
	attackers = ({ victim }) + attackers;
	any_attack = 1;
	victim->kill_ob(this_object());
	set_heart_beat(1) ;
	return 1;
}

int kill_first(object victim) {
	int i;

	if(query("��������"))  return 0;

	if (!attackers) {
		init_attack() ;
		attackers = ({ victim }) + attackers;
		any_attack = 1;
		set_heart_beat(1) ;
		victim->kill_ob(this_object());
		return 1;
	}

	i = member_array(victim, attackers);

	if (i > -1) {
		attackers = attackers - ({ victim });
		attackers = ({ victim }) + attackers;
		return 1;
	}
	attackers = ({ victim }) + attackers;
	any_attack = 1;
	victim->kill_ob(this_object());
	set_heart_beat(1) ;
	return 1;
}

void heart_beat() {
	unblock_attack() ;
	continue_attack() ;
}

void cease_all_attacks() {
	attackers = ({});
	any_attack = 0;
}

int remove_attacker(object obj) {
	if(member_array(obj, attackers) != -1)  attackers -= ({ obj });
	return 1; 
}

	object query_current_attacker() {
		if(sizeof(attackers) == 0)
			return 0;
		else
			return attackers[0];
	}

object *query_attackers() {
	if (sizeof(attackers)==0) {
		return 0 ;
	} else {
		return attackers ;
	}
}

void heal_up() {

	int hp, sp, maxh, maxs, time, bonus;
	object room;

	if (query("���")) return ;

	heal_time = heal_time + 1 ;
	time = query("ȸ���ӵ�") ;
	if (time==0) time = 20 ;
	if (heal_time>time) {
		hp = query("ü��") ;
		sp = query("���ŷ�") ;
		maxh = query("�ִ�ü��") ;
		maxs = query("�ִ����ŷ�") ;
		heal_time = 0 ;
		room = environment(this_object());
		if( !room ) return;
		if (hp==maxh && sp==maxs) return ;
		if( room->query("ȸ�����") ) {
			bonus = 99+(hp/20)+(room->query("ȸ�����"));
		}
		else {
			bonus = 99+(hp/50);
		}
		if (hp<maxh) {
			if( hp + bonus > maxh )
				set("ü��", maxh) ;
			else
				set ("ü��", hp+bonus) ;
		} else {
			set("ü��", maxh) ;
		}
		if (sp<maxs) {
			if( sp + bonus > maxs )
				set ("���ŷ�", maxs) ;
			else
				set ("���ŷ�", sp+bonus) ;
		} else {
			set ("���ŷ�", maxs) ;
		}
		if( !userp(this_object()) ) return;
		if ( !in_edit( this_object() ) && !in_input( this_object()) )
			write("\n"+write_prompt(1));
	}
}

void set_verbs(string *verbs) {

	int i ;
	string w1, w2 ;

	vb = verbs ;
	vb2 = allocate(sizeof(vb)) ;
	for (i=0;i<sizeof(verbs);i++) {
		if (sscanf(verbs[i],"%s %s",w1,w2)==2) {
			vb2[i]=w1+"s "+w2 ;
		} else {
			vb2[i]=verbs[i]+"s" ;
		}
	}
}

void set_verbs2 (string *verbs) {
	vb2 = verbs ;
}

string *get_verb() {

	int i ;

	i = random(sizeof(vb)) ;
	return ({ vb[i], vb2[i] }) ;
}
