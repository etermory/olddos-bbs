#include <uid.h>
#include <daemons.h>


mapping alias;
mapping xverb;

void add_alias(string verb, string cmd);

mapping query_nalias()
{
   if(alias)
      return alias + ([]);
   else 
      return ([]);
}

mapping query_xalias()
{
   if(xverb)
      return xverb + ([]);
   else 
      return ([]);
}
mapping query_aliases ()
{ 
  if (!alias)
    alias = ([]);
  if (!xverb)
    xverb = ([]);
  return alias + xverb; 
}

string query_alias (string str)
{
  string ret;
  if (!alias)
    alias = ([]);
  ret = alias[str];
  if (!ret)
    {
      if (!xverb)
	xverb = ([]);
      ret = xverb[str];
    }
  return ret;
}

void clear_aliases() { 
  if(geteuid(previous_object()) != ROOT_UID ) return;
  alias = ([ ]);
  xverb = ([ ]);
}
  
void add_alias (string verb, string cmd)
{
  if(geteuid(previous_object()) != ROOT_UID ) return;
  if (verb[0] == '$' && strlen(verb) > 1)
    {
      if(!xverb)
         xverb = ([]);
      verb = verb[1 .. strlen(verb) - 1];
      if(xverb[verb])
         xverb[verb] = cmd;
      xverb += ([ verb : cmd ]);
   }
  else 
    if (alias[verb])
      alias[verb] = cmd;
    else
      alias += ([ verb : cmd ]);
}

void remove_alias (string verb)
{
  if (alias[verb])
     map_delete(alias,verb);
  else
    if (xverb[verb])
      map_delete(xverb,verb);
}

string
replace_words (string orig, string *words)
{
  string ret, tmp;
  string *parts;
  int i, num;

  parts = explode (orig+"$","$");
  ret = orig;
  for (i = 0; i < sizeof(parts); i++)
    {
      if (parts[i][0] == '*')
	ret = replace_string(orig,"$*",implode(words," "));
      else 
	{
	  if (sscanf(parts[i],"%d%*s",num) == 0)
	    if (sscanf(parts[i],"%d",num) == 0)
	      continue;
	  if (num > 0 && num <= sizeof(words))
	    {
	      tmp = sprintf ("$%d",num);
	      ret = replace_string(ret,tmp,words[num-1]);
	    }
	}
    }
  return ret;
}


nomask string do_xverb (string str)
{
  string *xv, ret, *words;
  int i, lenxv;
  mapping tmpxv;

  if (!xverb)
     xverb = ([ ]) ;
   tmpxv = (mapping)ALIASES_D->query_global_xaliases() + xverb ;
  xv = keys (tmpxv);
  for (i = 0; i < sizeof(xv); i++)
  {
     lenxv = strlen(xv[i]);
     if(str[0 .. lenxv - 1] == xv[i])
     {
           if(strlen(str) > lenxv)
               str = str[lenxv..strlen(str)-1];
        else str = "";
         words = explode(str+" "," ");
         ret = replace_words(tmpxv[xv[i]],words);
        return ret;
     }
  }
  return 0;
}

string do_alias (string str)
{
  string *words, tmp, ret;
  int arg;

  if(this_player()->query_temp("��")) return str;
  tmp = do_xverb(str);
  if (tmp) return tmp;
  tmp = str;
  words = explode(str+" "," ");
  if (!words || sizeof(words) == 0) words = ({tmp});
  arg=sizeof(words)-1;
  if(!(tmp = alias[words[arg]]))
	tmp = (mixed)ALIASES_D->do_global_alias(words[arg]);
  if(tmp)
  {
	if (!arg)
        	ret = replace_words(tmp,({ "" }));
	else
		ret = replace_words(tmp,words[0..(arg-1)]);
	return ret;
  }
  return implode (words," ");
}
