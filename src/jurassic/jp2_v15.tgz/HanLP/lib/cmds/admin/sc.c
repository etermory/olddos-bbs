#include <mudlib.h>
#include <daemons.h>

inherit DAEMON;

#define write(str) message("general", str, this_player())

string sc_object( object ob, string indent )
{
  mixed obs;
  int i, s;

  obs = all_inventory( ob );
  s = sizeof( obs );
  for( i = 0 ; i < s ; i++ )
  {
    write(  indent + (i+1) + ":  " + identify( obs[i] ) +
      " EUID(" + geteuid( obs[i] ) + ")" +
       " UID(" +  getuid( obs[i] ) + ")" +
     "\n"  );

    sc_object( obs[i], "  "+indent );
  }
}

int cmd( string a ) 
{
  mixed ob;

  if( a ) {
	  ob = get_object(a);
	  if( !ob ) {
		  return notify_fail(  "����� ã���� �����ϴ�.\n");
	  }
  }
  else {  
	  ob = environment(this_player());
	  if( !ob ) {
		  return notify_fail(  "������� ����� �� ���� �����Դϴ�.\n");
	  }
  }
  write((  "Deep Scanning: " + identify( ob ) + " EUID(" + geteuid( ob ) +
    ") UID(" + getuid( ob ) + ")\n" )  );

  sc_object( ob, "  " );
  return 1;
}

