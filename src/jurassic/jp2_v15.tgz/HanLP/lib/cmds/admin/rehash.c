#include <daemons.h>
#include <mudlib.h>

inherit DAEMON ;

#define SYNTAX "Syntax: rehash [path]\n"

int cmd(string path) {
   
   notify_fail("Rehash: Could not locate requested path.\n");
 
   if(!path || path == "")   path = this_player()->query("������");
   else path = resolv_path("������", path);
 
   if(CMD_D->rehash(path)) {
    write("Rehash: " + path + " command table updated.\n");
   return 1; }
 
return 0;  }
