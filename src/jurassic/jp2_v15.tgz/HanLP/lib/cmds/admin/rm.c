#include <config.h>
#include <mudlib.h>
#include <daemons.h>
#include <uid.h>

inherit DAEMON ;

#define SYNTAX  "Syntax: rm [-r] [file pattern] [..] [..]\n"
 
static int remove_file(string file, int flag);

int cmd(string str) {
   mixed *files, *path, *multi;
   string dir;
   int flag, loop;
 
   notify_fail( SYNTAX );
   if(!str || str == "")  return 0;
 
   seteuid(getuid(this_object()));
 
   if(sscanf(str, "-r %s", str) == 1)  flag = 1;
 
 
   //   Check for multiple file deletion request
 
   multi = explode(str, " ");

   if(multi && sizeof(multi) > 1) {

        for(loop=0; loop<sizeof(multi); loop++)
          cmd( multi[loop] );

   return 1; }
 
 
   //  Check to see if the request is bad ("..*")

   if(str == "..*") {
   write("Rm: Illegal file pattern.\n");
   return 1; }
 
   str = resolv_path("������", str);
 
   //   Check the caller's write permissions in target directory
 
   path = explode(str, "/");
   
   dir = "/" + implode( path[0..sizeof(path)-2], "/" ) + "/";
   if(dir == "//")  dir = "";

   if((int)master()->valid_write(dir, previous_object(), "rm") == 0) {
   write("Rm: Permission denied in " + 
               (dir == "" ? "root directory" : dir) + ".\n");
   return 1; }
 
   //   Check for wildcards present in rm request
 
   files = get_dir(str);
 
   if(files) {
      files -= ({ "." });  files -= ({ ".." });
   }
 
   if(!files || !sizeof(files)) {
   write("Rm: No such pattern : " + str + "\n");
   return 1; }
 
   if(dir == "")  dir = "/";
 
   //   If only one selection match ...
 
   if(sizeof(files) == 1) 
        return remove_file(dir + files[0], flag);
 
   //   Otherwise loop through all the wildcard selections
 
   for(loop=0; loop<sizeof(files); loop++) 
        remove_file(dir + files[loop], flag);
 
return 1; }
 
//  This function removes individual files, and directories if
//  the flag passed returns a true value.
 
static int remove_file(string file, int flag) {
   int try;
 
   //   Check callers permissions on specific file/dir removal
 
   if((int)master()->valid_write(file, previous_object(), "rm") == 0) {
   write("Rm: " + file + " : Permission denied.\n");
   return 1; }
 
   if(directory_exists(file)) {

        //  If no recursive directory deletion ...

        if(!flag) {
        write("Rm: " + file + " is a directory.\n");
        return 1; }

        seteuid(ROOT_UID);                      // Quickly set us to root
        
        try = DIR_D->rm_dir(file, 1);

        seteuid(geteuid(previous_object()));    // And set us back
 
        if(!try || !rmdir(file)) {
        write("Rm: " + file + "/ failed.\n");
        return 1; }
 
        write("Rm: " + file + " recursively removed.\n");
 
   return 1; }
 
       write(rm(file) ? "Rm: " + file + " removed.\n" :
                        "Rm: " + file + " remove failed.\n");
 
return 1; }
