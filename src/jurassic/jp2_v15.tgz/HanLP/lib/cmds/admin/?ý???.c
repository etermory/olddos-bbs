#include <config.h>
#include <mudlib.h>

inherit DAEMON ;

#define SCALE           (1.0/10.0)

string parse_mem( int mem ) {
	if( mem > (1024 * 1024) )
		return (sprintf("%.3fM", (mem + 0.0) / 1024 / 1024));
	else
		return  ( mem / 1024 ) + "K" ;
}


int cmd() {

	int mem;
    mapping r;
    float cpu;
    string str, memory;

    r = rusage();
    cpu = SCALE * (r["utime"] + r["stime"]) / uptime();
    mem = memory_info();
    if( mem > (1024 * 1024) ) {
	    memory = parse_mem( mem )+" Byte";
    }
    else memory = mem+" Byte";

    str = "\n * �ӵ� �̸�   : "+mud_name()+
	  "\n * �ӵ� ��Ʈ   : "+mud_port()+
	  "\n * ���̺귯��  : "+MUDLIB_VERSION +
	  "\n * �ӵ� ����   : "+version()+
	  "\n * ���� �ð�   : "+ctime(time()-uptime())+
	  "\n * ���� �ð�   : "+ctime(time())+
	  "\n * ���� ����   : "+format_time(uptime())+
	  "\n * CPU ������  : "+cpu+" %"+
	  "\n * �޸𸮻��  : "+memory+
	  "\n * Object Load : "+all_object_size(0)+"\n\n";

    write(str);
    return 1;
}
