#include <mudlib.h>

inherit DAEMON ;

int is_define(string foo,int flag);

int cmd() { 

    string * config, * defines;
    string input,output;
    int i;

    input = read_file("/adm/include/runtime_config.h");

    if(!input)
	return notify_fail(" * �б� ���� : /adm/include/runtime_config.h\n");

    config = explode(input,"\n");
    defines = filter_array(config,"is_define",this_object(),0);
    for (i=0;i<sizeof(defines);i++) {
	sscanf( defines[i], "%*s__%s__%*s", defines[i] );
    }
    defines = filter_array(defines,"is_define",this_object(),1);
    for (i=0;i<sizeof(defines);i++) {
	defines[i] = "__"+defines[i]+"__"+" = "+get_config(i);
    }
    output = implode(defines,"\n");
    input = temp_file("cfg",this_player());
    save_file(input,output);
    this_player()->more(input);
    return 1; 
}

int is_define(string foo, int flag) {

    string tmp;

    if (!flag) return sscanf(foo,"%sdefine %s",tmp, tmp);
    else 
    {
	if(!sscanf(foo,"%sdefine %s",tmp, tmp)) return 1;
	else return 0;
    }

}
