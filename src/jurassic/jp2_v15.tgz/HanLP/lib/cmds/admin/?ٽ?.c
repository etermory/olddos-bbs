#include <config.h>
#include <mudlib.h>

inherit DAEMON;

#define SYNTAX "\n*���� : ��� �ٽ�\n\n"

int cmd( string a ) {
 
  object ob, new_ob, env;
  string name, file;
  int clone_number;

  seteuid( getuid( previous_object() ) );
  if( !a ) { notify_fail( SYNTAX ); return 0; }
 
   ob = get_object(a);
   
   if(!ob) {
   notify_fail("\n* "+han_obj(a)+" ã�� �� �����ϴ�.\n\n");
   return 0;  }
 
   if( interactive(ob) ) {
   notify_fail("\n* ���Ž�ų �� ���� ������Ʈ�Դϴ�.\n\n");
   return 0;  }
 
   env = environment( ob );
 
   name = file_name( ob );
   if( 2 != sscanf( name , "%s#%d", file, clone_number ) ) file = name;
 
   catch( this_player()-> force_me( "update " + file ) );
 
   if( !(new_ob = find_object(file)) ) {
   notify_fail("Renew: Couldn't update " + file + "\n");
   return 0;  }
 
   if( ob )  {
   ob-> move( VOID );
   ob-> remove();
   }
 
   if( clone_number ) new_ob = clone_object( file );
   write("* " + file_name( new_ob ) + " ���ŵǾ����ϴ�.");
 
   if( env )  {
   new_ob-> move( env );
   write( " to " + file_name( env ) );
  }
 
  write( "\n" );
 
return 1; }
