#include <config.h>
#include <mudlib.h>

inherit DAEMON;

void do_update(string file);

static void do_update(string file)
{
    mixed	res;
    object	ob, *obs;
    int		update;

    ob = find_object(file);
    if(ob)
    {
	obs = all_inventory(ob);
	obs = filter_array(obs, "filter_player", this_object());
	obs->move(VOID);
	if(ob) destruct(ob);
	if(ob) return;
	file_size("???");
	update = 1;
    }
    if(res = catch(file->apply_load())) {
	write(res+" : ���� \n");
	return;
    }
    if(obs) obs->move(find_object(file));
    return;
}

int cmd(string str)
{
    object      ob;

    if (!str) {
	notify_fail("\n * ���� : <ȭ�ϸ�> ������Ʈ\n\n");
	return 0;
    }
    ob = find_object(str+".c");
    if (!ob) return 1;
    do_update(file_name(ob));
    return 1;
}


int filter_player(object ob)
{
    return userp(ob);
}
