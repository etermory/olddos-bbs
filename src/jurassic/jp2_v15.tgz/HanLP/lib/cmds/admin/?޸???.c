#include <mudlib.h>
 
inherit DAEMON;

string parse_mem( int mem );

int cmd( string da_ob )
{
   int mem;
   object ob;
   
   if( da_ob )
      {
      ob = get_object( da_ob );
      if( !ob )
         {
	 write("Mem: Could not locate " + da_ob + ".\n");
         return 1;
      }
      mem = memory_info( ob );
   }
   else
      mem = memory_info();
   if( ob )
      printf("%s is presently consuming %s of memory.\n",
	     identify(ob), parse_mem(mem));
   else
 
   printf("%s is presently consuming %s of memory.\n",mud_name(), parse_mem(mem));
   return 1;
}


string parse_mem( int mem ) {
   if( mem > (1024 * 1024) )
	return (sprintf("%.3fM", (mem + 0.0) / 1024 / 1024));
   else
      return  ( mem / 1024 ) + "K" ;
}
