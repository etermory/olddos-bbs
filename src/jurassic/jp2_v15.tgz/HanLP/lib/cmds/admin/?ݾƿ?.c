#include <config.h>
#include <mudlib.h>

inherit DAEMON;

int cmd(string arg) {
    int i, s;
    string *stuff, ob;
    mixed *info;

    info = call_out_info();
    s = sizeof(info);
    i = s;
    stuff = ({ });

        stuff += ({ "\n ������Ʈ(ȭ�ϸ�)                   �Լ�                Delay" });
        stuff += ({ " ----------------------------------------------------------------------" });

        while (i--) {
            catch(ob = file_name(info[i][0]));
            stuff += ({ sprintf(" %-35s%-20s%5d", ob, info[i][1], info[i][2]) });
        }

    stuff += ({ " ----------------------------------------------------------------------" });
    stuff += ({ sprintf("\t     * ���� %d���� call_out() �Լ��� �������Դϴ�.\n", s) });

    this_player()->more(stuff, 1);

    return 1;
}
