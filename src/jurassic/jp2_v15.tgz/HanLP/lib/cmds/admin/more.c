#include <mudlib.h>

inherit DAEMON ;

int cmd(string str) {
    seteuid( geteuid( this_player() ) );
    return (int)this_player()->more(str);
    seteuid( getuid() );
}
