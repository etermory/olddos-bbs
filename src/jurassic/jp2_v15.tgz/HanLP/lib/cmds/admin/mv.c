#include <mudlib.h>
#include <daemons.h>

inherit DAEMON ;

static string get_path(string str, int dir_flag);
static string get_file(string str);
static int mv_file(string from, string to, int rflag, int iflag, int silent);

#define SYNTAX  "Syntax: mv [-rsfi] [source] [destination]\n"

int cmd(string str) {
    mixed *files;
    string flags, tpath, fpath, from, to, tmp1, tmp2;
    int loop, rflag, iflag, silent, dir_flag;

    seteuid( getuid(this_object()) );

    notify_fail( SYNTAX );
    if(!str || str == "")  return 0;

    if(sscanf(str, "-%s %s", flags, str) == 2) {
	if(sscanf(" " + flags + " ", "%sr%s", tmp1, tmp2) == 2)  rflag = 1;
	if(sscanf(" " + flags + " ", "%si%s", tmp1, tmp2) == 2)  iflag = 1;
	if(sscanf(" " + flags + " ", "%sf%s", tmp1, tmp2) == 2)  iflag = 0;
	if(sscanf(" " + flags + " ", "%ss%s", tmp1, tmp2) == 2)  silent = 1;
    }

    if(sscanf(str, "%s to %s", from, to) != 2 &&
	    sscanf(str, "%s %s", from, to) !=2)         return 0;

    if(to == ".")  to = (string)this_player()->query("������");

    if(to[strlen(to)-1] == '/')  dir_flag = 1;

    from = resolv_path("������", from);
    to   = resolv_path("������", to);

    if(from[strlen(from)-1] == '/') {
	from += "*";
	rflag = 1;
    } else if (rflag && directory_exists(from)) {
	from += "/*";
    }

    fpath = get_path(from, 0);
    tpath = get_path(to, dir_flag);

    if(!directory_exists(fpath)) {
	write("Mv: No such directory : " + fpath + "\n");
	return 1; 
    }

    if(!directory_exists(tpath)) {
	write("Mv: No such directory : " + tpath + "\n");
	return 1; 
    }

    if((int)master()->valid_write(fpath, previous_object(), "rm") == 0) {
	printf("Mv: Access denied in %s.\n", 
		(fpath == "" ? "root directory" : fpath));
	return 1; 
    }

    if((int)master()->valid_write(tpath, previous_object(), "mv") == 0) {
	printf("Mv: Access denied in %s.\n",
		(tpath == "" ? "root directory" : tpath));
	return 1; 
    }

    if (!directory_exists(to) && !rflag && from != to && 
	    sscanf(tpath, fpath + "%*s") != 1 &&
	    ( (directory_exists(from) && !file_exists(to)) ||
	      file_exists(from) ) ) {
	mv_file(from, to, 0, iflag, 0);
	return 1;
    }

    files = get_dir(from);
    if (files) {
	files -= ({ ".", ".." });
    }

    if(!files || !sizeof(files)) {
	write("Mv: No such pattern : " + from + "\n");
	return 1; 
    }

    if(sizeof(files) > 1) {

	if(tpath != "")   tpath = to + "/";

	if(!directory_exists(tpath)) {
	    write("Mv: No such directory : " + tpath + "\n");
	    return 1; 
	}

	if(tpath == fpath) {
	    write("Mv: Requested destination is the same as source files.\n");
	    return 1; 
	}

    }

    if(sscanf(tpath, fpath + "%s", tmp1) == 1 && tmp1 != "" && rflag) {
	write("Mv: Illegal to attempt recursive mv to same directory tree.\n");
	return 1; 
    }

    if(sizeof(files) == 1) {

	if (directory_exists(from))
	    if (file_exists(to)) {
		write("Mv: insufficient magic to move a directory into a file.\n");
		return 1;
	    } else if (directory_exists(to)) {
		if (sscanf(to, from +"%*s") == 1) {
		    write("Mv: Illegal to mv deeper into directory tree.\n");
		    return 1;
		}
		to += (tpath == "" ? "" : "/") + get_file(files[0]);
		mv_file(from, to, 0, iflag, 0);
		return 1;
	    }
	    if(!file_exists(fpath + files[0]) &&
		    !directory_exists(fpath + files[0])) {
		write("Mv: " + fpath + files[0] + " does not exist.\n");
		return 1; 
	    }

	    if(directory_exists(to))
		to += (tpath == "" ? "" : "/") + get_file(files[0]);

	    mv_file(fpath + files[0], to, rflag, iflag, 0);

	    this_player()->set("��������", to);

	    return 1; 
    }

    for(loop=0; loop<sizeof(files); loop++) 
	mv_file(fpath + files[loop], tpath + files[loop], rflag, iflag, silent);

    if(silent)  write("Mv: File move complete.\n");

    return 1; 
}

static int mv_file(string from, string to, int rflag, int iflag, int silent) {
    mixed *tmp;
    int loop;


    if(from == to) {
	write("Mv: Requested destination is the same as source file.\n");
	return 1; 
    }

    if(directory_exists(from)) {

	from += "/";

	if(!directory_exists(to)) {
	    catch( rename(from[0..strlen(from)-2], to) );
	    if(!silent && rflag)
		write("Mv: " + from + " directory moved to " + to + "\n");
	    return 1;
	}

	to += "/";

	tmp = get_dir(from);

	for(loop=0; loop<sizeof(tmp); loop++)
	    mv_file(from + tmp[loop], to + tmp[loop], rflag, iflag, silent);

	rmdir(from[0..strlen(from)-2]);

	    write("Mv: " + from + " directory moved to " + to + "\n");
	return 1;
    }

    if(iflag && file_exists(to)) {
	if(!silent)  write("Mv: " + to + " already exists.\n");
	return 1; 
    }

    catch( rename(from, to) );

    if(file_exists(from) || !file_exists(to)) {
	if(!silent) write("Mv: Could not move " + from + " to " + to + "\n");
    }

    else if(!silent) write("Mv: " + from + " moved to " + to + "\n");

    return 1; 
}

static string get_path(string str, int dir_flag) {
    mixed *tmp;
    string path;

    if(str == "/")       return "";
    else if(dir_flag)    return str;
    else if(directory_exists(str))  return str + "/";

    tmp = explode(str, "/");
    path = "/" + implode( tmp[0..sizeof(tmp)-2], "/") + "/";

    if(path == "//")  path = "";

    return path; 
}

static string get_file(string str) {
    mixed *tmp;

    tmp = explode(str, "/");

    return tmp[sizeof(tmp)-1]; 
}
