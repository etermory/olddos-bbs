#include <daemons.h>
#include <mudlib.h>
#include <logs.h>
#include <uid.h>

#define NO_USER_CALLS 1

inherit DAEMON;
inherit REF_D;

#define SYNTAX "Syntax: call [-<uid>] <object>;<function>;<arg>;<arg>\n"
#define FUNC_LIST ({ "query_skills", "query_aliases" })
#define TAB "\t"

static
string * do_call( object ob, string func, mixed args );

int cmd( string a )
{
  string str, *exp_a;
  mixed objs, funcs, args, tmp, ret, rets;
  object ob;
  int i, s, fi, fs;

  if( !a ) { notify_fail( SYNTAX ); return 0; }

  seteuid( geteuid( previous_object() ) );

  if(a[0] == '-')
  {
    if(a[1] == '-')
      a = a[2..<1];
    else if (geteuid(previous_object())
	     && adminp(geteuid(previous_object()))
	     && previous_object() == this_player()
	     && this_player() == this_player(1))
    {
      i = strsrch(a, ' ');
      if(i != -1)
      {
	seteuid(a[1..(i-1)]);
	a = a[(i+1)..<1];
      } else {
	notify_fail("call: seteuid: bad euid\n");
	return 0;
      }
    } else {
      notify_fail("call: seteuid: permission denied\n");
      return 0;
    }
  }

  exp_a = explode( a, ";" );
  s = sizeof( exp_a );
  objs = exp_a[0];
  if( s > 1 ) funcs = exp_a[1];
  else funcs = FUNC_LIST;
  if( s == 3 ) args = ({ exp_a[2] });
  if( s > 3 ) args = exp_a[2..(s-1)];

  objs = resolv_Ref( objs );
  if( objs == "users" ) objs = users();
  if( !pointerp( objs ) ) objs = ({ objs });
  tmp = ({ });
  s = sizeof( objs );
  for( i = 0 ; i < s ; i++ )
  {
    if( stringp( objs[i] ) ) ob = get_objects( objs[i],0,1 );
    else if( objectp( objs[i] ) ) ob = objs[i];
    if( !ob ) write(  "Can't identify " + identify( objs[i] ) +
      " as an object."  );

    else tmp += ({ ob });
  }
  if( !sizeof( tmp ) ) return 1;
  objs = tmp;

  funcs = resolv_Ref( funcs );
  if( !pointerp( funcs ) ) funcs = ({ funcs });
  tmp = ({ });
  s = sizeof( funcs );
  for( i = 0 ; i < s ; i ++ )
  {
    if( stringp( funcs[i] ) ) tmp += ({ funcs[i] });
    else write(  "Can't identify " + identify( funcs[i] )+
      " as a string."  );

  }
  if( !sizeof( tmp ) ) return 1;
  funcs = tmp;

  if( pointerp( args ) && ( s = sizeof( args ) ) )
    for( i = 0 ; i < s ; i++ )
      args[i] = resolv_Ref( resolv_str( args[i] ) );

  rets = ({ });
  s = sizeof( objs );
  fs = sizeof( funcs );
  for( i = 0 ; i < s ; i++ )
  {
    str = identify( objs[i] );
    for( fi = 0 ; fi < fs ; fi++ )
    {
      ret = do_call( objs[i], funcs[fi], args );
      if( ret[0] ) rets += ({ ret[0] });
      if( fs == 1 ) str =  str + ret[1] ;
      else str += (fi?"":"\n") +  ret[1] ;
    }
  write( str+"\n");
  }
  switch( sizeof( rets ) )
  {
    case 0: rets = 0; break;
    case 1: rets = rets[0];
  }
  return 1;
}

static
string *do_call( object ob, string func, mixed args )
{
  mixed ret, err;
  int i, s;
  string str;
  object shad;

  if( !function_exists( func, ob ) )
  {
    for( shad = shadow( ob, 0 ) ; shad ; shad = shadow( shad, 0 ) )
      if( function_exists( func, shad ) ) { ob = shad; break; }
    if( ob != shad ) return ({ 0, "- does not contain " + func + "()" });
  }
  str = "-> " + func;
  if( pointerp( args ) && ( s = sizeof( args ) ) )
  {
    str += "( ";
    for( i = 0 ; i < s ; i++ )
    {
      if( i ) str += ", ";
      str += identify( args[i] );
    }
    str += " )";
  } else str += "()";
    
#ifdef NO_USER_CALLS
  if (!adminp(this_player())) {
    if (userp(ob) && getuid(ob)!=getuid(this_player())) {
	return ({ 0, str+" = Illegal operation." }) ;
    }
  }
#endif
  if (!s) {
      err = catch(
        ret = call_other(ob, func)
      );
  } else {
      err = catch(
        ret = call_other(ob, ({ func }) + args)
      );
  }
  if( err ) return ({ 0, str + TAB + "= ERR(" + identify( err ) + ")" });
  return ({ ret, str + TAB + "= " + identify( ret )+"\n" });
}
