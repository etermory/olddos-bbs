#include <mudlib.h>
#include <daemons.h>

inherit DAEMON ;

static string get_path(string str, int dir_flag);
static string get_file(string str);
static int copy_file(string from, string to);
static int cp_file(string from, string to, int rflag, int iflag, int silent);

#define SYNTAX  "Syntax: cp [-rsfi] [source] [destination]\n"

int cmd(string str) {
    mixed *files;
    string flags, tpath, fpath, from, to, tmp1, tmp2;
    int loop, rflag, iflag, silent, dir_flag;

    seteuid( getuid(this_object()) );

    notify_fail( SYNTAX );
    if(!str || str == "")  return 0;

    if(sscanf(str, "-%s %s", flags, str) == 2) {
	if(sscanf(" " + flags + " ", "%sr%s", tmp1, tmp2) == 2)  rflag = 1;
	if(sscanf(" " + flags + " ", "%si%s", tmp1, tmp2) == 2)  iflag = 1;
	if(sscanf(" " + flags + " ", "%sf%s", tmp1, tmp2) == 2)  iflag = 0;
	if(sscanf(" " + flags + " ", "%ss%s", tmp1, tmp2) == 2)  silent = 1;
    }

    if(sscanf(str, "%s to %s", from, to) != 2 &&
	    sscanf(str, "%s %s", from, to) !=2)         return 0;

    if(to == ".")  to = (string)this_player()->query("������");

    if(to[strlen(to)-1] == '/')  dir_flag = 1;

    if(from[strlen(from)-1] == '/')  from += "*";

    from = resolv_path("������", from);
    to   = resolv_path("������", to);

    fpath = get_path(from, 0);
    tpath = get_path(to ,dir_flag);

    if(!directory_exists(fpath)) {
	write("Cp: No such directory : " + fpath + "\n");
	return 1; 
    }

    if(!directory_exists(tpath)) {
	write("Cp: No such directory : " + tpath + "\n");
	return 1; 
    }

    files = get_dir(from);
    files -= ({ "." });  files -= ({ ".." });

    if(!files || !sizeof(files)) {
	write("Cp: No such pattern : " + from + "\n");
	return 1; 
    }

    if(sizeof(files) > 1) {

	if(tpath != "")   tpath = to + "/";

	if(!directory_exists(tpath)) {
	    write("Cp: No such directory : " + tpath + "\n");
	    return 1; 
	}

	if(tpath == fpath) {
	    write("Cp: Requested destination is the same as source files.\n");
	    return 1; 
	}

    }

    if(sscanf(tpath, fpath + "%s", tmp1) == 1 && tmp1 != "" && rflag) {
	write("Cp: Illegal to attempt recursive cp to same directory tree.\n");
	return 1; 
    }

    if(sizeof(files) == 1) {

	if(!file_exists(fpath + files[0]) &&
		!directory_exists(fpath + files[0])) {
	    write("Cp: " + fpath + files[0] + " does not exist.\n");
	    return 1; 
	}

	if(directory_exists(to)) 
	    to += (tpath == "" ? "" : "/") + get_file(files[0]);

	cp_file(fpath + files[0], to, rflag, iflag, 0);

	this_player()->set("��������", to);

	return 1; 
    }

    for(loop=0; loop<sizeof(files); loop++) 
	cp_file(fpath + files[loop], tpath + files[loop], rflag, iflag, silent);

    if(silent)  write("Cp: File copy completed.\n");

    return 1; 
}

static int cp_file(string from, string to, int rflag, int iflag, int silent) {
    mixed *tmp;
    int loop;

    if(from == to) {
	write("Cp: Requested destination is the same as source file.\n");
	return 1; 
    }

    if(file_size(from) == -1) {
	write("Cp: " + from + " does not exist.\n");
	return 1; 
    }

    if(directory_exists(from)) {

	from += "/";  to += "/";

	if(rflag) {
	    tmp = get_dir(from);

	    if(!directory_exists(to))   
		mkdir( to[0..strlen(to)-2] );

	    for(loop=0; loop<sizeof(tmp); loop++)
		cp_file(from + tmp[loop], to + tmp[loop], rflag, iflag, silent);
	}

	else {
	    if(!silent)  write("Cp: " + from + " is a directory.\n");
	    return 1; 
	}

	rmdir( from[0..strlen(from)-2] );

	if(!silent)
	    write("Cp: " + from + " directory copied to " + to + "\n");
	return 1; 
    }

    if(iflag && file_exists(to)) {
	if(!silent) write("Cp: " + to + " already exists.\n");
	return 1; 
    }

    if(!copy_file(from, to))  {
	if(!silent)  write("Cp: Could not copy " + from + " to " + to + "\n");
    }

    else if(!silent)  write(" * " + from + " >==-->> " + to + "\n");

    return 1; 
}

static int copy_file(string from, string to) {
    string str;
    int size;

    size = file_size(from);
    str = read_file(from);

    if (file_exists(to))  rm(to);
    if (!save_file(to, str) || !file_exists(to)
	    || file_size(to) != size) {
	if(file_exists(to))  rm(to);
	return 1;
    }
    return 1;
}

static string get_path(string str, int dir_flag) {
    mixed *tmp;
    string path;

    if(str == "/")       return "";
    else if(dir_flag)    return str;
    else if(directory_exists(str)) return str + "/";

    tmp = explode(str, "/");
    path = "/" + implode( tmp[0..sizeof(tmp)-2], "/") + "/";

    if(path == "//")  path = "";

    return path; 
}

static string get_file(string str) {
    mixed *tmp;

    tmp = explode(str, "/");

    return tmp[sizeof(tmp)-1]; 
}
