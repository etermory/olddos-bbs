#include <mudlib.h>

inherit DAEMON;

int cmd(string str) {

	object th, env, *obs, ob;
    string name;
    
	th = this_player();
    name = th->query("�̸�");
	env = environment(this_player());

    if ((!str) || (str == " ")) {
	write("����� ȥ�� �߾�Ÿ��ϴ�.\n");
	say(han(name,"��")+" ȥ�� �߾�Ÿ��ϴ�.\n");
	return 1;
    }

	if( wizardp(th) ) {
		write("[1;37m*[0;33m ��� [1;30m:[1;37m "+str+"[37;0;40m\n");
		say("[1;37m*[0;33m "+name+" [1;30m:[1;37m "+str+"[37;0;40m\n");
	}
	else if( !th->query_attacker() ) {
		write("[0;32m*[0;33m ���[37;0;40m : "+str+"\n");
		say("[0;32m*[37;0m "+name+" [1;30m:[37;0m "+str+"\n");
	}
	else {
		write("[1;31m*[0;33m ���[37;0;40m : "+str+"\n");
		say("\n[1;31m*[37;0m "+name+" [1;30m:[37;0m "+str+"\n\n");
	}
	obs = all_inventory(env);
	foreach( ob in obs ) {
		string func;
		if( !ob->query("����") ) continue;
		if ((func = ob->query("say_func"))) {
			call_other(ob,func,th,name,str);
			continue;
		}
	}
    return 1;
}
