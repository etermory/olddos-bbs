#include <mudlib.h>
 
inherit DAEMON;

int cmd(string str) {
	write(read_file("/text/�ҽ�/�ҽ�"));

	return 1; 
}
