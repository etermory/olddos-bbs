#include <mudlib.h>
#include <daemons.h>

inherit DAEMON ;

int cmd(string arg)
{
	int size;
	object act_ob;
	string title, last, str, tmp, *ansi;

	act_ob = previous_object();

	if( arg && arg != "" ) {
		str = arg;
		ansi = ({ "RESET", "BOLD","BLACK","RED","GREEN",
				"ORANGE","YELLOW","BLUE","CYAN","MAGENTA",
				"WHITE","HRED","HGREEN","HYELLOW","HBLUE",
				"HMAGENTA","HCYAN","HWHITE","HIGH","LOW"
				});
		if( sscanf(str, "%*s%%^%s%%^%*s", tmp) > 2 ) {
			foreach( tmp in ansi ) {
				str = replace_string(str,"%^"+tmp+"%^","");
			}
		}
		size = strlen(str);
		if(size > 60)
		{
			write("�Ӹ����� 30�� ���Ϸθ� �ۼ��� �� �ֽ��ϴ�.\n");
			return 1;
		}
	}
	write("�Ӹ����� �����մϴ�.\n");
	act_ob->setenv("TITLE",arg);
	act_ob->do_new();

	title = act_ob->query_env("TITLE") ;
	last = act_ob->query_env("LAST") ;

	if (!title) title = ""; else title = title + " ";
	if (!last) last = " �� "; else last = " " + last + " ";
	write(title+han_iga(this_player()->query("�̸�"))+last+"�ִ�."+"\n");
	return 1;
}
