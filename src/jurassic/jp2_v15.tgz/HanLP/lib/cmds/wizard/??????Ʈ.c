#include <move.h>
#include <user.h>
#include <mudlib.h>
#include <ansi.h>

inherit DAEMON ;

object *tb;
string tb2;
mixed *i3;
int i2,i4,sz;

int cmd() 
{
   	object *obj, room;
   	int i, num = 1;
   	string list, temp, tmp, tmp2;

	room = environment(this_player());
	
   	obj = all_inventory(room);
	obj = filter_array(obj, "no_name", this_object());
	obj = sort_array(obj, "compare", this_object());
	sz=sizeof(obj);

	if(!sz) {
		write("\n* �̰����� ������Ʈ�� �����ϴ�.\n\n");
		return 1;
	}
	sscanf(file_name(obj[i]),"%s#%d",temp, tmp2);
	list = "\n * ���� �뿡 �ִ� ������Ʈ :\n\n";

	for (i = 1 ; i < sz ; i++)
	{
		if( sscanf(file_name(obj[i]),"%s#%d",tmp, tmp2) != 2 )
		    tmp = file_name(obj[i]);

  		if (temp == tmp)
	  	{
	    		num++; 
	    		temp = tmp;
	    		continue;
	  	}
	    	list += sprintf("\t\"%s : %d\n", temp, num);
	  	num = 1;
	  	temp = tmp;
	}
        if(sscanf(file_name(obj[sz-1]),"%s#%d",tmp, tmp2) != 2 )
	    tmp = file_name(obj[sz-1]);
       	list += sprintf("\t\"%s : %d\n", tmp, num);
	list += "\n";
   	write(list);
   	return 1;
}

int compare(object u1, object u2)
{
        string s1, s2;

        s1 = u1->query("�̸�");
        s2 = u2->query("�̸�");

        return strcmp (s1,s2) ;
}

int no_name(object obj)
{
        if(obj==this_player()) return 0;
        return 1;
}
