#include <mudlib.h>
#include <daemons.h>

inherit DAEMON ;

#define SYNTAX	"Syntax: data [object]\n"

int cmd(string str) {
    mapping list;
    mixed *klist;
    object what;
    string text;
    int loop;

    if(!str || str == "")  str = "��";

    what = get_object(str);

    if(!what) {
	notify_fail("\n* ����� �ҷ� �� �� �����ϴ�.\n\n");
	return 0; 
    }

    list = (mapping)what->query_ob_data();

    if(!list || !mapp(list)) {
	notify_fail("Data: That object does not have any stored data.\n");
	return 0; 
    }

    klist = keys(list);
    klist = sort_array(klist, "sort_keys", this_object());

    if(!klist || !sizeof(klist)) {
	notify_fail("Data: That object does not have any stored data.\n");
	return 0; 
    }

    text = "\n������Ʈ        : " + identify(what) + "\n\n";

    for(loop=0; loop<sizeof(klist); loop++)  {

	if(strlen(klist[loop]) > 7)  text += klist[loop] + "\t: ";
	else text += klist[loop] + "\t\t: ";

	text += identify(list[klist[loop]])+"\n";
    }

    text += "\n * " + sizeof(klist) + "���� ����Ÿ�� �ֽ��ϴ�.\n\n";

    this_player()-> more( explode( TERMINAL_D->filter_colours(
		    text), "\n") );

    return 1; 
}

static int sort_keys(string one, string two) {
    return strcmp(one, two);  
}
