#include <mudlib.h>

inherit DAEMON;

#define SYNTAX "\n* ����: [-ag] [���] ����\n\n"

#define GUEST_NO_DEST 1

static int cnt;

int strncmp(string str, string sub, int i) {
	int j;

	j = strlen(str);
	if (i > j)
		return strcmp(str, sub);
	else
		return strcmp(str[0..i-1], sub);
}

int dest_all(object act_ob, int silent) {
	int s;
	object *ob;

	ob = deep_inventory(act_ob);
	s = sizeof(ob);
	cnt += s;
	while (s--) {
		if (!ob[s])  continue;

		if (!silent)
			write("Desting: " + identify(ob[s]) + "\n");

		if (!(ob[s]->is_player() && interactive(ob[s]))) {
			if (adminp(this_player())) {
				catch(ob[s]->remove());
				if(ob[s])  destruct(ob[s]);
			} else write("Not allowed to remove players, Bad !\n");
		}
	}
	return 1 ;
}

int cmd(string str) {
	object ob, act_ob, *obs;
	string msg, opt;
	int clean, global, l, s;

	act_ob = previous_object();
	seteuid(geteuid(act_ob));

	notify_fail( SYNTAX );
	if (!str || str == "")  return 0;

	if (getuid(previous_object()) == "guest") {
		write ("Guest is not permitted to dest objects.\n") ;
		return 1 ;
	}

	if (str == "all")
		return dest_all(act_ob, 0);

	if (sscanf(str, "-%s %s", opt, str) == 2) {
		if (strsrch(opt, 'a') != -1)  clean = 1;
		if (strsrch(opt, 'g') != -1)  global = 1;
	}

	if (global) {
		str = resolv_path("������", str);
		l = strlen(str);
		obs = objects();
		s = sizeof(obs);

		write("Global destructing: " + str + "\n");

		cnt = 0;
		while (s--) {
			if (!obs[s])  continue;
			if (strncmp(file_name(obs[s]), str, l) == 0) {
				if (clean)
					dest_all(obs[s], 1);
				cnt++;
				if (obs[s]) {
					catch(obs[s]->remove());
					destruct(obs[s]);
				}
			}
		}

		write("������Ʈ(s) destructed: " + cnt + "\n");
	} else {
		if (!(ob = get_object(str))) {
			write("Dest: Could not locate that object.\n");
			return 1;
		}

		if (interactive(ob) && !adminp(this_player())) {
			write("Dest: Permission denied.\n");
			return 1;
		}
		if (clean)  dest_all(ob, 1);

		write("Destructing: " + identify(ob) + "\n");
		msg = (string)act_ob->query_mdest(ob);

		if (environment(ob) == this_player() ||
				environment(ob) == environment(this_player()))
			say( msg + "\n");

		catch(ob->remove());
		if (ob)  destruct(ob);
	}
	return 1;
}
