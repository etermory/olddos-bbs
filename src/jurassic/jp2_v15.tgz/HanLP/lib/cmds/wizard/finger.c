#include <daemons.h>
#include <mudlib.h>
#include <commands.h>

inherit DAEMON;

mapping requests;

void remote_finger(object me, string target, string mud);

void create() {
    seteuid(getuid());
}

int cmd(string str) {
    string tmp1,tmp2,tmp3,tmp4;

    if (!str) {
	this_player()->more(explode(FINGER_D->finger_all(), "\n"));
	return 1;
    }

    if (!sscanf(str, "%s %s", tmp1, tmp2)) {
	tmp1 = str;
	tmp2 = "";
    }

    do {
	if (sscanf(tmp1,"%s@%s", tmp3, tmp4)) {
	    if (tmp4 == "" || tmp4 == mud_name()) {
		if (!tmp3 || tmp3 == "")
		    this_player()->more(explode(FINGER_D->finger_all(), "\n"));
		else
		    this_player()->more(explode(FINGER_D->finger_user(tmp3), "\n"));
	    } else {
		if (!tmp3)
		    tmp3 = "" ;
	    }
	} else if (tmp1 && tmp1 != "") {
	    this_player()->more(explode(FINGER_D->finger_user(tmp1), "\n"));
	}
	str = tmp2;
	if (!str || !sscanf(str, "%s %s", tmp1, tmp2)) {
	    tmp1 = str;
	    tmp2 = 0;
	    str = 0;
	}
    } while (tmp1);

    return 1;
}
