#include <mudlib.h>
#include <daemons.h>

inherit DAEMON;

int cmd(string arg) {
	CMD_D -> show_cmds(arg) ;
    return 1;
}
