#include <mudlib.h>

inherit DAEMON;

#define SYNTAX	"\n* ���� : ��� û��\n\n"

int cmd(string str) {
	object *obs, ob;
	int i, flag;

	if(!str || str == "")  {
		return notify_fail(SYNTAX);
	}
	ob = get_object( str );

	if(!ob) {
		notify_fail("\n* û�ҽ�ų ����� ã�� �� �����ϴ�.\n\n");
		return 0;
	}
	obs = all_inventory(ob);

	if(!obs || !sizeof(obs)) {
		if(userp(ob)) {
			ob->set("�ѹ���",5000);
		}
		notify_fail("Clean: " + identify(ob) + " has no inventory.\n");
		return 0; }

		write("Cleaning " + (flag ? "and destructing " : "") +
				identify(ob) + ".\n");

		for (i=0; i<sizeof(obs); i++) {
			if (!living(obs[i]) && !obs[i]->id("board")) {
				write ("  Destructing:  "+file_name(obs[i])+"\n");
				obs[i]->remove();
				if(obs[i])  destruct(obs[i]);
			}
		}

		if(flag) {
			ob->remove();
			if(ob)  destruct(ob);
		}
		return 1; }
