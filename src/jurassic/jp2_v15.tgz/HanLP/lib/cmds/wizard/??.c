#include <move.h>
#include <mudlib.h>

inherit DAEMON ;

static int goto_location(object where);

#define SYNTAX	"\n * ���� : ��� ��\n\n"
 
int cmd(string str) {
   object ob;
   string tmp,flag ;
   int err;

   notify_fail( SYNTAX );

   if(!str || str == "")  return 0;

   if (sscanf(str,"%s %s",flag,tmp)==2) {
	if (flag!="-c") {
		notify_fail (flag+": unknown flag.\n") ;
		return 1 ;
	}
	str = tmp ;
    }
 
   if( ob = find_living(str) ) 
	return goto_location( environment(ob) );
 
   str = resolv_path("������", str);
 
    if (!flag || flag!="-c") {
       if(extract(str, strlen(str)-2, strlen(str)-1) != ".c")   str += ".c";

       if(!file_exists(str)) {
   	write("\n * ����� ã�� �� �����ϴ�. -.-;;;\n\n");
       return 1; }

   }
   err = catch( call_other(str, "???") );
 
   if (!ob = find_object(str)) {
     write("Goto: Could not load " + str + "\n");
     if(err) write("      " + err );
   return 1; }
 
   goto_location( ob );
 
return 1; }

static int goto_location(object where) {
   object old;
   int res;
 
   if(!where||!objectp(where)) return 0;
 
   old = environment( this_player() );
 
   if(old == where) {
     write("\n * �ٷ� �� �տ� �ִµ� � ����...\n\n");
     return 1;
   }
 
   res = this_player()->move_player( where, "" );

   if(res) 
     write("Goto: Could not move to " + identify(where) + ".\n");
 
return 1; }
