#include <config.h>
#include <mudlib.h>

inherit DAEMON ;

static mixed *process_choice(string str) {
   mixed *dir, *tmp, *hold;
   string file, where, patt, dump;
   int loop;
 
   file = resolv_path("������", str);
 
   tmp = explode(file, "/");
   where = "/" + implode(tmp[0..(sizeof(tmp)-2)], "/") + "/";
 
   if(sscanf(tmp[sizeof(tmp)-1],"%s\\*",patt) == 1) patt += "%s";
 
   dir = get_dir(where);
 
   for(hold = ({}),loop=0; loop<sizeof(dir); loop++)
   if(sscanf(dir[loop], patt, dump) == 1)
   hold += ({ (where + dir[loop]) });
 
return hold; }

static int file_completion(string str) {
   mixed *tmp, *result;
   string command;
 
   if(str[strlen(str)-1] != '*') return 0;
 
   tmp = explode(str, " ");
   result = process_choice(tmp[sizeof(tmp)-1]);
 
   if(!result || !sizeof(result))
   write("Unable to complete designated filename [" + 
	 tmp[sizeof(tmp)-1] + "]\n");
   else if(sizeof(result) > 1)
   write("Multiple possible filename completions [" +
	 tmp[sizeof(tmp)-1] + "]\n");
 
   else { 
   tmp[sizeof(tmp)-1] = result[0];
   command = implode(tmp, " ");
   this_player()->force_me(command);  }
 
return 1; }

int cmd(string str) {
   int size;
   string name, path;
 
   path = this_player()->query("������");
   name = geteuid(this_player());
   seteuid(getuid());
 
   if(!str) {
      str = "/text/doc";
      if(str[strlen(str)-1] == '/')  str = str[0..strlen(str)-2];
      if(!str || !directory_exists(str))  str = "/doc";
      this_player()->set("������", str);
      printf("%s\n", str);
      return 1;
   }
   if(file_completion(str)) return 1;

   str = resolv_path(path, str);
   replace_string("//", "/", str);
   if ((int)master()->valid_read(str, this_player()) == 0) {
      notify_fail(sprintf("%s:  permission denied\n", str));
      return 0;
   }
   size = file_size(str);
   if (size > -1) {
      notify_fail(sprintf("%s:  not a directory\n", str));
      return 0;
   }
   if (size == -1) {
      notify_fail(sprintf("%s:  no such file or directory\n", str));
      return 0;
   }
   this_player()->set("������", str);
    printf("%s\n", str);
   return 1;
}

string help() {
   return("Command: cd\nSyntax: cd <directory>\n"+
      "This command changes your current directory to the\n"+
      "one you specify.  If directory begins with a / then\n"+
      "the command will look from the root, otherwise it\n"+
      "will look in the child directories of your current\n"+
      "directory.  .. will back up to the parent of your\n"+
      "current directory.  Thus cd ../obj will attempt to\n"+
      "move to the directory obj which is a child of your\n"+
      "current parent directory.\n"+
      "cd with no arguments will move you to your home dir-\n"+
      "ectory if you are a student, or the /doc directory if\n"+
      "not.\n");
}
