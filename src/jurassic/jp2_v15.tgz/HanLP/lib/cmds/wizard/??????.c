#include <mudlib.h>

inherit DAEMON;

mapping groups;

void fix(string str, int grouplen);

int cmd(string str)
{
   string output;
   string line, *group, name;
   int counter, counter2;
   object who;

   groups=master()->query_groups();
   group=sort_array(keys(groups), "do_alpha", this_object());

   output = sprintf("\n * %s�� ���ε��� ����Դϴ�.:\n\n",MUD_NAME);

   for(counter=0; counter<sizeof(group); counter++)
   {
if( (str=="-s") && ( sizeof( groups[ group[counter] ] ) < 2 ) ) continue;
      groups[group[counter]]=sort_array(groups[group[counter]],
                  "do_alpha", this_object());
      line="";
      for(counter2=0; counter2<sizeof(groups[group[counter]]); counter2++)
      {
         name=groups[group[counter]][counter2];
         who=find_player(name);
         if(who && visible(who, this_player()))
            line+="*";
         line+=name+" ";
      }
      output += sprintf("  %s: %-=65s\n", group[counter], line);
   }
   write(output + "\n �̸� �տ� \"*\"�� ǥ�õ� ����� ���� �������Դϴ�.\n\n");
   return 1;
}

int do_alpha(string str1, string str2)
{
   return strcmp(str1, str2);
}

int filter_root(string who)
{
   if(member_array(who, groups["root"])>-1)
      return 0;
   return 1;
}
