#define PUBLIC		0
#define READ_ONLY	1
#define OWNER_ONLY	2
#define LOCKED		3
#define MASTER_ONLY	4
#define PRIVATE		5

