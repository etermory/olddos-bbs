#ifndef _DEBUG_H
#define _DEBUG_H
#ifdef DEBUG_MACRO
static int _debug_level;
#define set_debug_level(x) _debug_level = x;
#ifdef TELL
#define debug(x,y) if (x & _debug_level) tell_object(find_player(TELL),y)
#else
#define debug(x,y) if (x & _debug_level) write(y)
#endif
#else
#define debug(x,y)
#define set_debug_level(x)
#endif DEBUG_MACRO

#define T_UNKNOWN  0
#define T_INT      1
#define T_STRING   2
#define T_POINTER  3
#define T_OBJECT   4

#define TYPES ({ \
        "UNKNOWN", \
        "INT    ", \
        "STRING ", \
        "POINTER", \
        "OBJECT ", \
        })

#endif _DEBUG_H
