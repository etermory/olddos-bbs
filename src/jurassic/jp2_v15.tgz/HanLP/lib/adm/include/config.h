#ifndef __CONFIG_H
#define __CONFIG_H
 
#define __HANLP
#ifdef __HANLP
#define NO_PKILL
#endif

#define MUDLIB_NAME		"HanLP"
#define GAME_NAME		"JuDessic"
#define MUDLIB_VERSION_NUMBER	"1.0.0"
#define MUDLIB_VERSION		(MUDLIB_NAME + " " + MUDLIB_VERSION_NUMBER)
#define UDATA_DIR(x)		"/data/std/"+first_char(x)+"/"+(x)+"/"
#define PDATA_FILE(x)		"/data/std/"+first_char(x)+"/"+(x)+"/Soul"
#define UDATA_FILE(x)		"/data/std/"+first_char(x)+"/"+(x)+"/Body"
#define NEW_MAIL_FILE(x)		"/data/std/"+first_char(x)+"/"+(x)+"/Mail/New_mail"
#define USER_BACKUP_DIR(x)	"/data/�ڻ�/"+first_char(x)+"/"+(x)+"."+ktime(time())
#define DATA_DIR		"/data"
#define CONFIG_DIR		"/adm/config/"
#define SECURE_DIR		"/adm/"
#define HOME_DIRS		"/u/"
#define LOG_DIR			"/log/"
#define DEBUG_DIR		"/log/adm"
#define TMP_DIR			"/adm/tmp/"
#define ARCHIVE_DIR		"/data/attic/"
#define SIMUL_EFUN_DIR		"/adm/master/efun/"
#define USER_OB			"/std/user"
#define CONNECTION		"/std/connection"
#define MASTER_OB		master()
#define GROUP_OB		MASTER_OB
#define ACCESS_OB		MASTER_OB
#define THIS_MUD 		implode(explode(mud_name(), " "), ".")
#define SIMUL_EFUN_OB		"/adm/master/simul_efun"
#define ADMIN_EMAIL		"mgn@chollian.net"
#define START			"/d/std/����"
#define VOID			"/d/std/���"
#define WIZ_CMDS 		"/cmds/wizard"
#define USER_CMDS 		"/cmds/player:/cmds/skills"
#define ADM_CMDS 		"/cmds/admin"
#define NEW_WIZ_PATH WIZ_CMDS + ":" + USER_CMDS

#define BLOCK_ATTACK

//#define NO_PKILL
//#define PROFILING 1
#define MAX_LOG_FILE_SIZE (100 * 1024)
#define MAX_LOG_DAYS 0
#undef CAP_NAME_MASTER_ONLY
#define LOCAL_TIME_ZONE 1
#endif
