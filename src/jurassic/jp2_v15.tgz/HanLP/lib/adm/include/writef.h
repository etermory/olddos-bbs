#ifndef __WRITEF_H
#define __WRITEF_H

#define TRUNC_LEFT	0x0001
#define TRUNC_RIGHT	0x0002
#define TRUNCATE	0x0003
#define TRUNC_ELL	0x0004
#define JFY_RIGHT	0x0010
#define JFY_CENTRE	0x0020
#define QUIET		0x0100

#endif

#define PAD "                                                             "
#define ERR "*************************************************************"

