#define MAX_CAPACITY 5000
#define MAX_VOLUME 500
#define USER_MASS 7500
#define USER_BULK 1000

inherit "/std/user/tsh.c";
inherit "/std/user/autoload.c";
inherit "/std/user/save.c";
inherit "/std/user/bitflags.c";
 
