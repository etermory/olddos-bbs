#define set_short(s)	set("short", s) 
#define set_long(s)	set("long", s) 
#define set_weight(i)	set("weight", i)
#define set_name(n)	set("�̸�", n)
#define set_id(x)	set("���̵�", x)
#define set_light(i)	set("light", i)

string query_short() { return _query("short"); }
string query_long() { return _query("long"); }
string query_name() { return _query("�̸�"); }
string query_cap_name() { return _query("�̸�"); }
string *query_id() { return _query("���̵�"); }

