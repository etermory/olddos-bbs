#ifdef 0
inherit "/std/user/alias";
inherit "/std/user/wild_card";
#endif
