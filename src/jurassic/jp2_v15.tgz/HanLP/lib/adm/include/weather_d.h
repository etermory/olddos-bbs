#define START_TIME 0
#define START_DATE 1
#define START_MONTH 0
#define START_YEAR 100

#define START_GAME_TIME 631170000

#define DAY_PHASE_FILE "/adm/config/�Ϸ�ð�����Ÿ"
#define NUM_DAY_PHASES 8

// #define WEATHER_FILE "/adm/etc/weather.data"
#define WEATHER_FILE "/adm/config/��������Ÿ"
#define NUM_WEATHER 6

// #define MONTH_FILE "/adm/etc/yeardates.data"
#define MONTH_FILE "/adm/config/���ؽð�����Ÿ"
#define NUM_MONTHS 6

// #define MOON_FILE "/adm/etc/moon.data"
#define MOON_FILE "/adm/config/�޵���Ÿ"
#define NUM_MOON_PHASES 8
#define MOON_PERIOD 28

#define DAY_LENGTH 7200
#define YEAR_LENGTH 1296000
