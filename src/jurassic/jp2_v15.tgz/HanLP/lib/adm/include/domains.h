#ifndef __DOMAINS_H
#define __DOMAINS_H

#define DOMAIN_LIST ({ "security", "game", "teaching", "interface", "network", "knowledge", "HANLP", "TMI" })

#define LEVEL_LIST ({ "player", "guest", "staff", "manager" })

#define DOMAIN_DIRS ({ "std", "�Խ���", "����" })

#define ENTRY_LEVEL 2
#define MIN_SPONSOR_LEVEL 3


#endif
