#ifndef MESSAGES_H
#define MESSAGES_H
#define MSG_COMBAT      "combat"
#define MSG_EMOTE       "emote"
#define MSG_INFO        "info"
#define MSG_LOOK        "look"
#define MSG_MOVEMENT    "movement"
#define MSG_PROMPT      "prompt"
#define MSG_HELP	"help"
#define MSG_UNKNOWN	"unknown"
#define MSG_CHANNEL     "channel"
#define MSG_SAY         "say"
#define MSG_TELL        "tell"
#define MSG_SYSTEM      "system"
#define MSG_DEBUG       "debug"
#define MSG_COMMAND     "command"
#define MSG_PRIVATE     "private"
#endif
