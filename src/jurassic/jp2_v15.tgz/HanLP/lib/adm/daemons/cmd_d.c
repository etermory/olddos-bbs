#include <uid.h>
#include <config.h>

mapping cmd_table;

void	create();
int	rehash(string path);
string 	find_cmd(string cmd, string *path);

void create() {
	seteuid(ROOT_UID);
	cmd_table = ([ ]);
	rehash(USER_CMDS);
	rehash(WIZ_CMDS);
	rehash(ADM_CMDS);
}

string find_cmd(string cmd, string *path) {
	int i;

	for (i=0;i<sizeof(path);i++) {
		if(!cmd_table[path[i]] && !rehash(path[i])) continue;
		if(member_array(cmd, cmd_table[path[i]]) > -1)
			return path[i] + "/" + cmd;
	}
	return 0;
}

int rehash(string path) {
	string *bin_ls, *result, tmp;
	int i, s;
        if(!stringp(path)) { write("Badness! Invalid path!\n"); return 0; }

	if(file_size(path) != -2) return 0;
	bin_ls = get_dir(path + "/");
        s = sizeof( bin_ls );
        result = allocate( s );
	for( i = 0 ; i < s ; i++ ) {
            if(sscanf(bin_ls[i], "%s.c", tmp) == 1)
		result[i] = tmp;
        }
        result -= ({ 0 });
	cmd_table[path] = result;
	return 1;
}

string *list_cmds(string path) {
	if (!cmd_table[path]) rehash(path);
	return cmd_table[path];
}
	
void qq() {
        save_object("/tmp/cmd_d");
}

string show_cmds(string arg) {
	string *tt;
	int i;
	int c;
	string *ttt;
	int j;
   	string * output;
  	string line;

  	output = ({});
	tt=keys(cmd_table);
	for (i=0;i<sizeof(tt);i++) {
		output += ({"COMMAND PATH: "+tt[i]});
		c=0;
		line = "";
		ttt=cmd_table[tt[i]];
		for (j=0;j<sizeof(ttt);j++)
		{
  			if (!(c%4)) 
  			{
				output += ({line});
				line = "";
  			}
			c++;
			line += sprintf("%-19s",ttt[j]);
		}
  		output += ({line,""});
	}
  	this_player()->more( output );
	return "Ok.\n";
}
