#include <uid.h>
#include <config.h>
#include <mudlib.h>
#include <login_macros.h>
#include <daemons.h>

inherit DAEMON;

#define LINE1 \
"=+=--=+=--=+=--=+=--=+=--=--=+=--=+=--=+=--=+=--=+=--=+=--=+=--=+=--=+=--=+=\n"
#define LINE2 \
"----------------------------------------------------------------------------\n"

string finger_group(string group);
int filter_users(object who);

mapping groups;

void create() {
    seteuid(ROOT_UID);
}

object restore_data(string name) {
    object link;

    if (find_player(name) && interactive(find_player(name))) {
	return (object)find_player(name)->query_link();
    }

    link = new(CONNECTION);
    seteuid(name);
    export_uid(link);
    seteuid(ROOT_UID);

    link->set("�̸�", name);
    if (link->restore()) {
	return link;
    }

    link->remove();
    if(link) destruct(link);
    if(link) log_file("fingerdest",sprintf("Connection of %s not dested by finger daemon, on %s.\n", name, ctime(time())));
    return 0;
}

string finger_user(string who) {
    object link;
    mixed tmp1;
    string msg;

    link = restore_data(who);
    if (!link) {
	if (sscanf(who, "(%s)", who))
	    return finger_group(who);
	return "* �׷� ����ڰ� �����ϴ�.\n";
    }

    msg = "\n ��  �� : " + who+"\n"+
	" ��  �� : ";
    if (adminp((string)link->query("�̸�")))
	msg += "����\n";
    else if (link->query("���"))
	msg += "���ڵ�\n";
    else
	msg += "�����\n";

    msg += "�����̸�: "+((string)link->RNAME ? (string)link->RNAME : "???")+"\n";
    
    tmp1 = find_player(who);

    if (tmp1) {
	if (!filter_users(tmp1))
	    tmp1 = 0;
    }

    if (!link->query("last_on"))
	msg += (tmp1 ? "On since: " : "��������: ") + "�ش����\n";
    else
	msg += ((tmp1 && !tmp1->query("����")) ? "On since: " : "��������: ") +
	    ctime((int)link->query("last_on")) + "\n"+"�� �� ��: "+
	    (string)link->query("������") + " \n";

    if (tmp1) {
	tmp1 = query_idle_string(tmp1, 1);
	if (strlen(tmp1) > 0)
	    msg += tmp1 + "\n";
    }

    tmp1 = (string)link->query("email");
    msg += "�� �� ó: " + tmp1 + "\n";

    if (!find_player(who) || !interactive(find_player(who))) {
	link->remove();
	if(link) destruct(link);
	if(link) 
	    log_file("fingerdest",sprintf("Connection of %s not dested by finger daemon, on %s.\n", link->query("�̸�"), ctime(time())));
    }
    return "\n" + msg + "\n";
}

string finger_group(string group) {
    int i, j;
    string msg;
    object link;
    mixed tmp1, tmp2, tmp3, tmp4, tmp5;
    string *group2;

    groups = master()->query_groups();
    if (!group || undefinedp(groups[group]))
	return "Finger: There is no such group.\n";

    group2 = groups[group];
    j = group2 ? sizeof(group2) : 0;

    msg = LINE1;
    if (j == 0) {
	msg += "[" + mud_name() + "] No members of " +
	    group + " group (" + ctime(time()) + ").\n";
    } else {
	msg += "[" + mud_name() + "] " + j +
	    (j == 1 ? " user" : " users") + " " +
	    "in " + group + " group (" + ctime(time()) + ").\n";
	msg += LINE2;
	msg += sprintf("%-12s%-20s%-14s%-28s", "Login", "Real Name",
		"Domain", "On\n");
	msg += LINE2;
	group2 = sort_array(group2, "do_alpha", this_object());
	for (i = 0; i < j; i++) {
	    tmp1 = group2[i]; /* logid id */
	    link = find_player(tmp1);
	    if (link)
		link = link->query_link();
	    else
		link = restore_data(tmp1);
	    if (!link)
		continue;

	    tmp2 = (string)link->RNAME;

	    tmp3 = DOMAIN_D->query_domain(link);
	    if ((tmp3 == 0) || (tmp3 == ""))
		tmp3 = "None";

	    tmp4 = find_player(tmp1);
	    if (!tmp4 || !filter_users(tmp4))
		tmp5 = "Last  ";
	    else
		tmp5 = "Since ";
	    if (!link->query("last_on"))
		tmp5 += "(Unavailable)";
	    else
		tmp5 += ctime((int)link->query("last_on"));

	    msg += sprintf("%-12s%-20s%-14s%28s",
		    (string)tmp1,extract((string)tmp2, 0, 18),(string)tmp3,(string)tmp5 + "\n");

		    if (!find_player(tmp1))
			link->remove();
	}
    }

    return msg + LINE1;
}

string finger_all() {
    object *who, link;
    int i, j;
    string msg;

    who = users();
    who = filter_array(who, "filter_users", this_object());

    who = sort_array(who, "sort_users", this_object());
    j = who ? sizeof(who) : 0;

    msg = LINE1;
    if (j == 0) {
	msg += "[" + mud_name() + "] No one is presently " +
	    "connected (" + ctime(time()) + ").\n";
    } else {
	msg += "[" + mud_name() + "] " + j +
	    (j == 1 ? " user" : " users") + " " +
	    (j == 1 ? "is " : "are ") + "presently connected (" +
	    ctime(time()) + ").\n";
	msg += LINE2;
	msg += sprintf("%-12s%-20s%-14s%-7s%-21s", "Login", "Real Name",
		"Position", "Idle", "Where\n");
	msg += LINE2;
    }
    for (i = 0; i < j; i++) {
	link = (object)who[i]->query_link();
	if (!link || !link->RNAME)
	    continue;

	msg += sprintf("%-12s%-20s%-14s%-7s%-21s",
		(string)link->NAME,
		extract((string)link->RNAME, 0, 18),
		(string)DOMAIN_D->query_domain_level(link),
		query_idle_string(who[i], 0),
		extract(query_ip_name(who[i]), 0, 20) + "\n");
    }

    return msg + LINE1;
}

    int filter_users(object who) {
	if (!this_player() && who->query("����"))
	    return 0;
	else if (!visible(who, this_player()))
	    return 0;

	return !((int)who->query("����"));
    }

    int filter_root(string who) {
	if (member_array(who, groups["root"]) > -1)
	    return 0;
	return 1;
    }

    int do_alpha(string str1, string str2) {
	return strcmp(str1, str2);
    }

    int sort_users(object one, object two) {
	return strcmp((string)one->NAME, (string)two->NAME);
    }
