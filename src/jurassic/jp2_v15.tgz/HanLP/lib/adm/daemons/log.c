#include <mudlib.h>

inherit DAEMON;

void _log(string str, string mes)
{
    log_file(str, mes);
}

string _get_log(string str)
{
    return read_file("/log/"+str);
}

void _remove_log(string str)
{
    rm ("/log/"+str);
}

string _get_file(string str, int begin, int numlines)
{
    if (!numlines) return read_file(str);
    return read_file(str, begin, numlines);
}
