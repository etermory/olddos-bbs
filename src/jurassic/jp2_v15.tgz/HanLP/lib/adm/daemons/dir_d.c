#include <mudlib.h>
#include <config.h>
#include <uid.h>

inherit DAEMON ;

#define PROTECT ({ "README" })
static int remove_contents(string path, int flag);
static int mv_dir(string from, string to);

int rm_dir(string dir, int flag) 
{
    string tmp;

    if (geteuid(previous_object()) != ROOT_UID &&
	    !adminp(geteuid(previous_object())))
	return 0;

    if (!dir || dir == "") return 0;
    if (file_size(dir) != -2) return 0;
    if (sscanf(dir, SECURE_DIR + "%s", tmp) == 1) return 0;

    return remove_contents(dir + "/", flag);
}

static int mv_file(string from, string to) {
    mixed *tmp;
    int loop;

    if(directory_exists(from)) {
	from += "/";
	if(!directory_exists(to)) mkdirs(to);
	to += "/";
	tmp = get_dir(from);
	for(loop=0; loop<sizeof(tmp); loop++)
	    mv_file(from + tmp[loop], to + tmp[loop]);

	rmdir(from[0..strlen(from)-2]);
	return 1;
    }
    if(file_exists(to)) return 1;
    catch( rename(from, to) );
    return 1; 
}

int move_dir(string from, string to) {

    if( !from || !to ) 
	return notify_fail(" * ���� : ���� ����\n");

    if(!directory_exists(from)) 
       return notify_fail(" * ���� : ���丮 �ƴ�\n");

    if(from == to) 
	return notify_fail("* ���� : ���� �̸�\n");
    
    return mv_file( from, to );
}

static int remove_contents(string what, int flag) {
    mixed *dir, *subdir;
    string path, subpath, *protect_list, tmp;
    int loop, subloop, cnt = 0;

    protect_list = PROTECT;

    dir = get_dir(what);
    if (!dir || !(loop = sizeof(dir)))
	return -1;

    do {
	reset_eval_cost();
	while (loop--) {
	    path = what + dir[loop];

	    if (file_size(path) == -2) {
		subdir = get_dir(path + "/");
		if (subdir && (subloop = sizeof(subdir))) {
		    while (subloop--) {
			subpath = path + "/" + subdir[subloop];

			if (file_size( subpath ) == -2) {
			    while (file_size((tmp = what + subdir[subloop] + cnt)) != -1)
				cnt++;
			    rename(subpath, tmp);
			}
			else if (flag || member_array(subdir[subloop],
				    protect_list) == -1) {
			    rm(subpath);
			}
		    }
		}
		rmdir(path);
	    }
	    else if (flag || member_array(dir[loop], protect_list) == -1) {
		rm(path);
	    }
	}

	dir = get_dir(what);
    } while (dir && (loop = sizeof(dir)));

    return 1;
}

static int backup_contents(string what, int flag) {
    mixed *dir, *subdir;
    string path, subpath, *protect_list, tmp;
    int loop, subloop, cnt = 0;

    protect_list = PROTECT;

    dir = get_dir(what);
    if (!dir || !(loop = sizeof(dir)))
	return -1;

    do {
	reset_eval_cost();
	while (loop--) {
	    path = what + dir[loop];

	    if (file_size(path) == -2) {
		subdir = get_dir(path + "/");
		if (subdir && (subloop = sizeof(subdir))) {
		    while (subloop--) {
			subpath = path + "/" + subdir[subloop];

			if (file_size( subpath ) == -2) {
			    while (file_size((tmp = what + subdir[subloop] + cnt)) != -1)
				cnt++;
			    rename(subpath, tmp);
			}
			else if (flag || member_array(subdir[subloop],
				    protect_list) == -1) {
			    rm(subpath);
			}
		    }
		}
		rmdir(path);
	    }
	    else if (flag || member_array(dir[loop], protect_list) == -1) {
		rm(path);
	    }
	}

	dir = get_dir(what);
    } while (dir && (loop = sizeof(dir)));

    return 1;
}
