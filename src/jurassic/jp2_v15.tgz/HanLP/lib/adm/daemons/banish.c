#include <uid.h>
#include <daemons.h>

#define SAVE_F        "/data/adm/daemons/banish"
#define BANNED_NAMES  ({ })

string *names;
void save();

void create()
{
    seteuid(ROOT_UID);
    if (file_exists(SAVE_F + ".o"))
	restore_object(SAVE_F);
    if (!names)
	names = BANNED_NAMES;
}

int check_banned_name(string name)
{
    int i;
    string *test;

    if (!names || name == "")
	return 0;
    test = ({ name });
    for (i = 0; i < sizeof(names); i++)
	if (name == names[i] || sizeof(regexp(test, names[i])) > 0)
	    return 1;
    return 0;
}

int banish_name(string name)
{
    if (geteuid(previous_object()) != ROOT_UID || name == "")
	return 0;
    if (member_array(name, names) == -1)
    { 
	names += ({ name });
	save(); return 1; 
    }
    return -1;
}

int remove_banished_name(string name)
{
    if (geteuid(previous_object()) != ROOT_UID || name == "")
	return 0;
    if (member_array(name, names) >= 0)
      { names -= ({ name });
	save(); return 1; }
    return -1;
}

string *query_banished_names()
{
   if (geteuid(previous_object()) != ROOT_UID) return ({ });
   return copy(names);
}

void save()
{ 
    mixed *dir;

    dir = get_dir("/data/adm/daemons");
    if(!dir || !sizeof(dir))
	mkdirs( "/data/adm/daemons/" );
    save_object(SAVE_F);
}
