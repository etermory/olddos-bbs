#include <config.h>
#include <uid.h>
#include <daemons.h>
#include <origin.h>

int s_sec;
string reason;

string query_reason() { return reason; }
int query_shutdown() { return s_sec; }

void backup_debug_log()
{
	if(!directory_exists(DEBUG_DIR) ) mkdirs(DEBUG_DIR);
	if(file_size(LOG_DIR+"debug.log") >= 0 )
		rename(LOG_DIR+"debug.log",DEBUG_DIR+"/debug.old");
}

void do_shutdown(int how) {
	seteuid(ROOT_UID);
	backup_debug_log();
	EMOTE_D->save_data();
	users()->save_data();
	shutdown(how);
}

void count_down(int how);

varargs int start_shutdown( int how, int delay, string reasoning ) {
	if( geteuid( previous_object() ) != ROOT_UID ) return s_sec;
	if( delay < 0 ) return s_sec;
	reason = reasoning;
	if( !delay )
	{
		do_shutdown( how );
		return time();
	}
	if(s_sec) remove_call_out("count_down");
	s_sec = time() + ( delay * 60 );
	count_down( how );
	return s_sec;
}

void count_down( int how )
{
	int delay;

	delay = ( s_sec - time() ) / 60;

	if( !delay || delay < 1 ) {
		message( "shutdown", "\n [1;37m* [1;31mREBOOT[1;37m *[37;0;40m ������ ����Ǿ����ϴ�. �ٽ� ������ �ֽʽÿ�.\n\n",users());
		do_shutdown( how );
		return;
	}
	if( delay > 60 ) {
		if( delay % 60 ) {
			call_out( "count_down", 60, how );
			return;
		}
		message( "shutdown", "\n [1;37m* [1;31mREBOOT[1;37m *[37;0;40m "+delay+"�� �ڿ� ������ ����˴ϴ�.\n\n",users());
		call_out( "count_down", 60, how );
		return;
	}
	else if( delay > 10 ) {
		if( delay % 10 ) {
			call_out( "count_down", 60, how );
			return;
		}
		message( "shutdown", "\n [1;37m* [1;31mREBOOT[1;37m *[37;0;40m "+delay+"�� �ڿ� ������ ����˴ϴ�.\n\n",users());
		call_out( "count_down", 60, how );
		return;
	}
	message( "shutdown", "\n [1;37m* [1;31mREBOOT[1;37m *[37;0;40m "+delay+"�� �ڿ� ������ ����˴ϴ�.\n\n",users());
	call_out( "count_down", 60, how );
	return;
}

int stop_shutdown()
{
	s_sec = 0;
	reason = 0;
	remove_call_out( "count_down" );
	if( this_player() )
		message("shutdown", "\n [1;37m* [1;31mREBOOT[1;37m *[37;0;40m �������� ���� ���� �Ǿ����ϴ�.\n\n", users());
	return 1;
}
