#include <uid.h>
#include <domains.h>
#include <daemons.h>
#include <mudlib.h>

inherit DAEMON;

string player, wizard;

varargs string query_domain(object link, string domain)
{
    mapping domains, entry;
    string level;

    if(!link || !objectp(link))  return 0;

    domains = link->query("domains");
    if (!domains || !keys(domains)) return 0;  // default case, for a player
    if(!domain)  domain = domains["primary"];
    if(domain) entry = domains[domain];
    if(entry) level = entry["level"];
    if(!level)  return 0;
    return copy(domain);
}

varargs string query_domain_sponsor(object link, string domain)
{
    mapping domains, entry;

    domains = link->query("domains");
    if( !domains || !keys(domains)) return 0;
    if(!domain) domain = domains["primary"];
    if( member_array( domain, DOMAIN_LIST ) < 0) return 0;
    entry = domains[domain];
    return copy( ( entry ? entry["sponsor"] : 0 ) );
}

varargs string query_domain_level(object link, string domain)
{
    mapping domains, entry;

    if(!link)  return player;

    domains = (mapping)link->query("domains");
    if (!domains || !keys(domains))
	return (int)link->query("���") ? wizard : player;
    if (!domain) domain = domains["primary"];
    entry = domains[domain];
    return copy ((entry ? entry["level"] : wizard));
}

nomask int set_domain(object link, string domain, string lev, string sponsor )
{
    mapping domains, rec;

    if (getuid(previous_object() ) != ROOT_UID) return 0;
    domains = link->query("domains");
    if (nullp(domains) || !keys(domains)) domains = ([ ]);
    if (member_array(domain, DOMAIN_LIST ) < 0) return 0;
    if (member_array( lev, LEVEL_LIST ) < 0) return 0;

    seteuid(getuid()) ;

    if( member_array(lev,LEVEL_LIST) < ENTRY_LEVEL && domain != 0 )
    {
	map_delete(domains, domain);
	if(!undefinedp(domains["primary"])
		&& domains["primary"] == domain)
	    map_delete(domains,"primary");
	link->set("domains", domains);
	return 1;
    }

    rec = ([ "level" : lev, "sponsor" : sponsor ]);
    domains[domain] = rec;
    if( member_array(lev,LEVEL_LIST) >= ENTRY_LEVEL &&
	    ! domains[ "primary" ] )
	domains[ "primary" ] = domain;
    link->set("domains", domains);
    return 1;
}

nomask int set_primary_domain(object link, string d)
{
    mapping domains;

    if (geteuid(previous_object()) != ROOT_UID) return 0;
    domains = (mapping)link->query("domains");
    if (!domains || !keys(domains) || !domains[d]) return 0;
    if ( member_array(d, DOMAIN_LIST ) < 0) return 0;
    if ( member_array(domains[d]["level"],LEVEL_LIST) < ENTRY_LEVEL)
	return 0;
    domains["primary"] = d;
    return 1;
}

nomask string query_primary_domain(object link)
{
    mapping domains;
    domains = (mapping)link->query("domains");
    if (!domains || !mapp(domains)) return 0;
    return copy(domains["primary"]);
}

void create()
{
    switch(sizeof(LEVEL_LIST))
    {
	case 0:
	    player="";
	    wizard="";
	    break;
	case 1:
	    player=wizard=LEVEL_LIST[0];
	    break;
	default:
	    player=LEVEL_LIST[0];
	    wizard=LEVEL_LIST[1];
    }
}
