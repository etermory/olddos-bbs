#define ANSI(p) sprintf("%c["+(p)+"m", 27)
#define ESCMAC(p) sprintf("%c"+(p), 27)

static mapping term_info;

void
create()
{

    term_info = ([
      "UNKNOWN":
        ([ "RESET":"", "BOLD":"",
           "FLASH":"","UNDERSCORE":"","REVERSE":"",
           "HREVERSE":"","CLEAR":"","HOME":"",
           "BLACK":"", "RED":"", "GREEN":"",
           "ORANGE":"","YELLOW":"", "BLUE": "",
           "CYAN":"", "MAGENTA":"", "WHITE": "",
           "HRED":"", "HGREEN":"","HBLACK":"",
           "HYELLOW":"", "HBLUE":"",
           "HMAGENTA":"", "HCYAN":"",
           "HWHITE":"", "B_BLACK":"", "B_RED":"",
           "B_GREEN":"", "B_ORANGE":"",
           "B_YELLOW":"", "B_BLUE":"","B_MAGENTA":"",
           "B_CYAN":"", "B_WHITE": "",
           "B_HRED":"",
           "B_HGREEN":"",
           "B_HYELLOW":"",
           "B_HBLUE":"",
           "B_HMAGENTA":"",
           "B_HCYAN":"",
           "B_HWHITE":"",
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "FULL":
        ([ "RESET":ANSI("2;37;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI("0;30"), "RED":ANSI("0;31"), "GREEN":ANSI("0;32"),
           "ORANGE":ANSI("0;33"),"YELLOW":ANSI("0;33"), "BLUE": ANSI("0;34"), 
           "CYAN":ANSI("0;36"), "MAGENTA":ANSI("0;35"), "WHITE": ANSI("37;0;40m"), 
           "HBLACK":ANSI(1)+ANSI(30),
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "LINUX":
        ([ "RESET":ANSI("2;37;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HBLACK":ANSI(1)+ANSI(30),
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "FULL":
        ([ "RESET":ANSI("2;37;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HBLACK":ANSI(1)+ANSI(30),
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "VT100":
        ([ "RESET":ANSI("2;37;0;40"), "BOLD":ANSI(1), 
           "BLACK":ANSI("0;30"), "RED":ANSI("0;31"), "GREEN":ANSI("0;32"),
           "ORANGE":ANSI("0;33"),"YELLOW":ANSI("0;33"), "BLUE": ANSI("0;34"), 
           "CYAN":ANSI("0;36"), "MAGENTA":ANSI("0;35"), "WHITE": ANSI("37;0;40"), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37),
           "HBLACK":ANSI(1)+ANSI(30),
           "HIGH":ANSI("49"), 
           "LOW":ANSI("48"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "ANSI":
        ([ "RESET":ANSI("2;37;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "VT202":
        ([ "RESET":ANSI("2;37;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "VT102":
        ([ "RESET":ANSI("2;37;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "VT52":
        ([ "RESET":ANSI("2;37;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":"", "ENDTERM":""
         ]),
      "XTERM":
        ([ "RESET":ANSI("37;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":ESCMAC("[?5h"), "ENDTERM":ESCMAC("[?5l")
         ]),
      "XTERM-COLOR":
        ([ "RESET":ANSI("36;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI(1)+ANSI(7),"CLEAR":ESCMAC("[2J"),"HOME":ESCMAC("[H"),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33),"YELLOW":ANSI(33), "BLUE": ANSI(34), 
           "CYAN":ANSI(36), "MAGENTA":ANSI(35), "WHITE": ANSI(37), 
           "HRED":ANSI(1)+ANSI(31), "HGREEN":ANSI(1)+ANSI(32),
           "HBLACK":ANSI(1)+ANSI(30),
           "HYELLOW":ANSI(1)+ANSI(33), "HBLUE":ANSI(1)+ANSI(34),
           "HMAGENTA":ANSI(1)+ANSI(35), "HCYAN":ANSI(1)+ANSI(36),
           "HWHITE":ANSI(1)+ANSI(37), "B_BLACK":ANSI(40), "B_RED":ANSI(41),
           "B_GREEN":ANSI(42), "B_ORANGE":ANSI(43), 
           "B_YELLOW":ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),"B_MAGENTA":ANSI(45),
           "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI("41;1"), 
           "B_HGREEN":ANSI("42;1"), 
           "B_HYELLOW":ANSI("43;1"), 
           "B_HBLUE":ANSI("44;1"), 
           "B_HMAGENTA":ANSI("45;1"), 
           "B_HCYAN":ANSI("46;1"), 
           "B_HWHITE":ANSI("47;1"), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":ESCMAC("[?5h"), "ENDTERM":ESCMAC("[?5l")
         ]),
      "FREEDOM":
        ([ "RESET": ESCMAC("G0"), "BOLD":ESCMAC("G@"), "FLASH":ESCMAC("G2"),
           "BLACK":"", "RED":"", "GREEN":"", "ORANGE":"", "YELLOW":"",
           "BLUE":"", "BLACK":"", "RED":"", "GREEN":"", "ORANGE":"",
           "YELLOW":"", "BLUE":"", "CYAN":"", "MAGENTA":"", "BLACK":"",
           "WHITE":"", "B_RED":ESCMAC("GD"), "B_GREEN": ESCMAC("GD"),
           "B_ORANGE":ESCMAC("G4"), "B_YELLOW":ESCMAC("G4"),
           "B_BLUE":ESCMAC("G4"), "B_CYAN":ESCMAC("GD"),
           "B_BLACK": ESCMAC("GD"), "B_WHITE":ESCMAC("G4"), "B_MAGENTA":("G4"),
           "STATUS":"", "WINDOW":"", "INITTERM":"", "ENDTERM":""
         ]),
      "ANSI-STATUS":
        ([ "RESET": ANSI("37;40;0"), "BOLD":ANSI(1), "FLASH":ANSI(5),
           "BLACK":ANSI(30), "RED":ANSI(31), "GREEN":ANSI(32),
           "ORANGE":ANSI(33), "YELLOW":ANSI(33), "BLUE":ANSI(34),
           "CYAN": ANSI(36), "MAGENTA": ANSI(35), "BLACK":ANSI(30),
           "WHITE":ANSI(37), "B_RED":ANSI(41), "B_GREEN":ANSI(42),
           "B_ORANGE":ANSI(43), "B_YELLOW": ANSI(1)+ANSI(43), "B_BLUE":ANSI(44),
           "B_CYAN": ANSI(46), "B_BLACK":ANSI(40), "B_WHITE":ANSI(47),
           "B_MAGENTA":ANSI(45), "STATUS":ESCMAC("[23;24r")+ESCMAC(8),
           "WINDOW":ESCMAC(7)+ESCMAC("[0;22r")+ESCMAC("[22H\n"),
           "INITTERM":ESCMAC("[H")+ESCMAC("[J")+ESCMAC("[23;24r")+
                      ESCMAC("23H\n"),
           "ENDTERM":ESCMAC("[0r")+ESCMAC("[H")+ESCMAC("[J")
         ]),
      "AIXTERM":
        ([ "RESET":ANSI("36;40;0"), "BOLD":ANSI(1), 
           "FLASH":ANSI(5),"UNDERSCORE":ANSI(4),"REVERSE":ANSI(7),
           "HREVERSE":ANSI("1;7"),"CLEAR":ESCMAC("[2J"),
	   "HOME":ESCMAC("[H"), "BLACK":ANSI(30), "RED":ANSI(31),
	   "GREEN":ANSI(32),"ORANGE":ANSI(33),"YELLOW":ANSI(33),
	   "BLUE": ANSI(34), "CYAN":ANSI(36), "MAGENTA":ANSI(35),
	   "WHITE": ANSI(37), "HBLACK":ANSI(90), "HRED":ANSI(91),
	   "HGREEN":ANSI(92), "HYELLOW":ANSI(93), "HBLUE":ANSI(94),
           "HMAGENTA":ANSI(95), "HCYAN":ANSI(96), "HWHITE":ANSI(97),
           "B_BLACK":ANSI(40), "B_RED":ANSI(41) , "B_GREEN":ANSI(42),
	   "B_ORANGE":ANSI(43), "B_YELLOW":ANSI(43), "B_BLUE":ANSI(44),
           "B_MAGENTA":ANSI(45), "B_CYAN":ANSI(46), "B_WHITE": ANSI(47),
           "B_HRED":ANSI(101), "B_HGREEN":ANSI(102), 
           "B_HYELLOW":ANSI(103), "B_HBLUE":ANSI(104), 
           "B_HMAGENTA":ANSI(105), "B_HCYAN":ANSI(106), 
           "B_HWHITE":ANSI(107), 
           "STATUS":"", "WINDOW":"",
           "INITTERM":ESCMAC(""), "ENDTERM":ESCMAC("")
         ]),

    ]);
}
mapping query_term_info(string type) {
    return (term_info[type] ? term_info[type] : term_info["UNKNOWN"]);
}

string *query_terms() { return keys(term_info); }

int query_term_support(string str) {
    return (term_info[str] ? 1 : 0);
}

#include <ansi.h>


string strip_ansi (string str) {
    int i,j ;
    string *strippable ;
    strippable = ({ BLK,RED,GRN,YEL,BLU,MAG,CYN,WHT,
	 HIR, HIG, HIY, HIB, HIM, HIC, HIW,
	BBLK, BRED, BGRN, BYEL, BBLU, BMAG, BCYN, BWHT,
	HBRED, HBGRN, HBYEL, HBBLU, HBMAG, HBCYN, HBWHT,
	NOR, BOLD, CLR, HOME, REF, BIGTOP, BIGBOT, SAVEC, REST,
	REVINDEX, SINGW, DBL, FRTOP, FRBOT, UNFR, BLINK, U ESC,
	REV ESC, HIREV ESC }) ;
    i = strsrch(str,ESC) ;
    if (i==-1) return str ;
    for (j=2;j<9;j++) {
	if (i+j==strlen(str)) return str[0..i-1] ;
	if (member_array(str[i..i+j],strippable)>-1) {
	    if (i==0) {
		str = str[j+1..<1] ;
	    } else {
		if (i+j==strlen(str)-1) {
		    str = str[0..i-1] ;
		} else {
	    	    str = str[0..i-1]+str[i+j+1..<1] ;
		}
	    }
	    return strip_ansi(str) ;
	}
    }
    if (i==0) {
	str = str[1..<1] ;
    } else {
	if (i=sizeof(str)-1) {
	    str = str[0..i-1] ;
	} else {
	    str = str[0..i-1] + str[i+1..<1] ;
	}
    }
    return strip_ansi(str) ;
}

string filter_colours(string str) {
  string tmp;

  return str;
   str = strip_ansi(str) ;
  while (sscanf(str, "%*s%%^%s%%^%*s", tmp) > 2)
    str = replace_string(str, "%^"+tmp+"%^", "");
  return str;
}

