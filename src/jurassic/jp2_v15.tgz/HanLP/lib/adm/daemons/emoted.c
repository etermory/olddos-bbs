/* 							99/04/12 AM 01.30 MaGuN
 * 
 * 	HanLP�� ���ؼ� ���θ��� �κ��Դϴ�.
 * 	string ������ ������ ���� ����� �� �ֽ��ϴ�.
 *
 *
 *  	�ڽ��ΰ��          ����� ���� ���.
 *
 *  	$N - �ڽ�           ��� 	this_player
 *  	$I - ���(��)       �̸�(��)	this_player
 *  	$S - ���(��)       �̸�(��)	this_player
 *  	$J - ���(��)       �̸�(��)	this_player
 *
 *  	$T - ���           ���	target
 *  	$D - ���(��)       ���(��)	target
 *  	$O - �ڽ�(��)       ���(��)    target
 *  	$A - �ڽ�(��)       ���(��)    target
 * 
 *      $M - ����ڰ� �Է��� ������ ��� ( ������ �⺻���� modifier�� ��� )
 */
#include <uid.h>
#include <config.h>
#define SAVE_FILE	"/data/adm/daemons/emote"

mapping emotes;

void save()
{ 
    mixed *dir;

    dir = get_dir("/data/adm/daemons");
    if(!dir || !sizeof(dir)) mkdirs( "/data/adm/daemons/" );
    save_object(SAVE_FILE);
}

int query_prevent_shadow() { return 1; }
string *query_emotes() { return keys(emotes); }
string *query_emote(string verb) { return emotes[verb]; }

void delete_emote(string verb) { 
    map_delete(emotes, verb);
    save();
    return;
}

void create()
{
    seteuid(ROOT_UID);
    emotes = ([]);
    if (file_exists(SAVE_FILE + ".o"))
	restore_object(SAVE_FILE);
}

int add_emote(string verb, string *body)
{
    if ( !verb || !body ) return 0;
    emotes[verb] = body;	
    save();
    return 1;
}

varargs int tell_emote(string str, object target, string special)
{
    object owner, env;
    string *word, *tword, *eword, modifier=0, name, tname;
    string tmp1, tmp2;
    int sz, i;

    if(!str||str==""||str == "#") return 0;

    if( sscanf(str, "%s���� (:%s:)", str, modifier) !=  2 )
	sscanf(str, "%s (:%s:)", str, modifier);

    word = explode(str, " ");
    tword = explode(str, " ");
    eword = explode(str, " ");
    word += ({ "\n" });
    tword += ({ "\n" });
    eword += ({ "\n" });

    if (!(sz = sizeof(word))) return 0;
    owner = this_player();
    name = owner->query("�̸�");
    if(!target) tname = name;
    else tname = target->query("�̸�");
    env = environment(owner);
    if(!env) return 0;

    for (i=0; i < sz; i++) {
	if( sscanf(word[i], "%s$M%s", tmp1, tmp2) == 2 ) {
	    if (special)
		word[i] = tword[i] = eword[i] = tmp1+special+tmp2;
	    else if(modifier)
		word[i] = tword[i] = eword[i] = tmp1+modifier+tmp2;
	    else
		word[i] = tword[i] = eword[i] = tmp1+""+tmp2;
	}
	else if( sscanf(word[i], "%s$N%s", tmp1, tmp2) == 2 ) {
	    word[i] = tmp1+"���"+tmp2;
	    tword[i] = eword[i] = tmp1+name+tmp2;
	}
	else if( sscanf(word[i], "%s$T%s", tmp1, tmp2) == 2 ) {
	    if( owner == target ) {
		word[i] = tword[i] = eword[i] = tmp1+"�ڽ�"+tmp2;
	    }
	    else {
		tword[i] = tmp1+"���"+tmp2;
		word[i] = eword[i] = tmp1+tname+tmp2;
	    }
	}   
	else {
	    switch(word[i]) {
		case "$I":
		    word[i] = "�����";
		tword[i] = eword[i] = han_iga(name);
		break;
		case "$S":
		    word[i] = "�����";
		tword[i] = eword[i] = han_iga(name);
		break;
		case "$J":
		    word[i] = "�����";
		tword[i] = eword[i] = han_obj(name);
		break;
		case "$O":
		    if( owner == target ) {
			word[i] = tword[i] = eword[i] = "�ڽ���";
		    }
		    else {
			tword[i] = "�����";
			word[i] = eword[i] = han_obj(tname);
		    }
		break;
		case "$A":
		    if( owner == target ) {
			word[i] = tword[i] = eword[i] = "�ڽŰ�";
		    }
		    else {
			tword[i] = "��Ű�";
			word[i] = eword[i] = han_and(tname);
		    }
		
		break;
		case "$D":
		    if( owner == target ) {
			word[i] = "�����";
			tword[i] = eword[i] = han_desc(name);
		    }
		    else {
			tword[i] = "�����";
			word[i] = eword[i] = han_desc(tname);
		    }

		break;
	    }
	}
    }
    if( target && target != owner ) {
	word = implode(word, " ");
	tword = implode(tword, " ");
	eword = implode(eword, " ");
	message("tell_emote", word, owner);
       	message("tell_emote", tword, target);
	message("tell_emote", eword, env, ({  owner, target }) );
	return 1;
    }
    word = implode(word, " ");
    eword = implode(eword, " ");
    message("tell_emote", word, owner);
    message("tell_emote", eword, env, ({  owner }) );
    return 1;
}

varargs int parse(string command, string str )
{
    string name, etc, *emotion;
    object owner, target, env;

    emotion = emotes[command];
    if( !emotion ) return 0;

    owner = this_player();
    env = environment( owner );

    if( !str ) return tell_emote(emotion[0]);
    if( sscanf( str,"%s %s", name, etc ) == 2 ) {
	target = present( name, env );
	if(!target) return tell_emote( emotion[0], owner, str );
	else return tell_emote( emotion[1], target, etc );
    }
    target = present( str, env );
    if(!target) return tell_emote( emotion[0], owner, str );
    return tell_emote( emotion[1], target, etc );
}
