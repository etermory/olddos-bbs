#include <uid.h>
#include <filepriv.h>


mapping group_list, permission_list;

static nomask string check_access(string file, string group);

void create() {

    group_list = ([ getuid()	: "������Ʈ", ]);

    permission_list = ([
	    "������Ʈ"       : ([ "data" : "rw", "/" : "r-" ]),
	    "non-members"	: ([ "/" : "r-" ]),
	    ]);
}

nomask int valid_access(string file, string eff_user) {
    string group, perm;

    if (member_array(eff_user, keys(group_list)) == -1) group = "non-members";
    else group = group_list[eff_user];

    perm = check_access(file, group);
    switch(perm) {
	case "rw": return (READ | WRITE);
	case "r-": return (READ);
	case "-w": return (WRITE);
	case "--":
	default:   return NONE;
    }
    return NONE;
}

static nomask string check_access(string tmp, string group) {
    int i;
    string *parts;

    if (permission_list[group][tmp]) return permission_list[group][tmp];

    parts = explode(tmp, "/");

    if (sizeof(parts) == 1) {
	return (permission_list[group]["/"] ?
		permission_list[group]["/"] :
		permission_list["non-members"]["/"]);
    }

    for (i=sizeof(parts)-1;i>=0;i--) {
	tmp = implode(parts[0..i], "/");
	if(permission_list[group][tmp]) {
	    return permission_list[group][tmp];
	}
    }
    return permission_list[group]["/"] ?
	permission_list[group]["/"] :
	permission_list["non-members"]["/"];
}

nomask string *query_domain_members() {
    string *members;

    members = keys(group_list);
    members -= ({ getuid() });
    return members;
}
