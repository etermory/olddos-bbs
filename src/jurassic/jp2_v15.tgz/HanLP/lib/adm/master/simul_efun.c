#include <mudlib.h>
#include <uid.h>
#include <config.h>
#include <writef.h>

#include "/adm/master/efun/base_name.c"
#include "/adm/master/efun/compat.c"
#include "/adm/master/efun/adminp.c"
#include "/adm/master/efun/creator_file.c"
#include "/adm/master/efun/domain_master.c"
#include "/adm/master/efun/dump_variable.c"
#include "/adm/master/efun/exclude_array.c"
#include "/adm/master/efun/existence.c"
#include "/adm/master/efun/find_object_or_load.c"
#include "/adm/master/efun/format_string.c"
#include "/adm/master/efun/format_time.c"
#include "/adm/master/efun/getopts.c"
#include "/adm/master/efun/gettype.c"
#include "/adm/master/efun/identify.c"
#include "/adm/master/efun/idle.c"
#include "/adm/master/efun/index.c"
#include "/adm/master/efun/match_string.c"
#include "/adm/master/efun/path_file.c"
#include "/adm/master/efun/pronouns.c"
#include "/adm/master/efun/mkdirs.c"
#include "/adm/master/efun/shout.c"
#include "/adm/master/efun/slice_array.c"
#include "/adm/master/efun/system.c"
#include "/adm/master/efun/tell_room.c"
#include "/adm/master/efun/tilde_path.c"
#include "/adm/master/efun/uniq_array.c"
#include "/adm/master/efun/unique_mapping.c"
#include "/adm/master/efun/update_file.c"
#include "/adm/master/efun/vt100.c"
#include "/adm/master/efun/wrap.c"
#include "/adm/master/efun/iwrap.c"
#include "/adm/master/efun/getoid.c"
#include "/adm/master/efun/member_group.c"
#include "/adm/master/efun/resolv_path.c"
#include "/adm/master/efun/data.c"
#include "/adm/master/efun/domain_log_file.c"
#include "/adm/master/efun/get_object.c"
#include "/adm/master/efun/tell_act.c"
#include "/adm/master/efun/temp_file.c"
#include "/adm/master/efun/visible.c"
#include <config.h>
#include <commands.h>
#include <daemons.h>
#include <login.h>
#include <uid.h>
#include <logs.h>

int destruct(object destructee)
{
   return efun::destruct(destructee);
}

nomask varargs void shutdown(int code)
{
   object prev;
   
   seteuid(getuid(this_object()));
   prev = previous_object();
   if (geteuid(prev) != ROOT_UID) {
      return;
   }
    log_file(SHUTDOWN_LOG, " - " +
      (this_player() ? geteuid(this_player()) : ROOT_UID) +
      "�� ���� ������ ����� : " + ctime(time()) + "\n");
   efun::shutdown(code);
}

nomask int exec(object to_obj, object from_obj) {
   string prev;
   
   if (file_name(this_object()) != SIMUL_EFUN_OB) return 0;
   prev = base_name(previous_object());
   if (prev == CONNECTION || prev == CMD_SU || prev == LOGIN_D) {
      return efun::exec(to_obj, from_obj);
   }
   return 0;
}

nomask int export_uid(object ob) {
   if (ob == master()) return 0;
   seteuid(geteuid(previous_object()));
   return efun::export_uid(ob);
}

nomask int set_eval_limit(int num) {
 if ( getuid(previous_object()) != ROOT_UID ) return 0;
 efun::set_eval_limit(num);
  return 1;
}

int Is_Windows() {
	if( __ARCH__ == "Cygwin-32" ) return 1;
	return 0;
}
