varargs void shout(string msg, mixed exclude)
{
   if (objectp(exclude))
      exclude = ({ exclude });
   else if (!pointerp(exclude))
      exclude = ({ });
   if (this_player())
      exclude += ({ this_player() });
   message("shout", msg, users(), exclude);
}
