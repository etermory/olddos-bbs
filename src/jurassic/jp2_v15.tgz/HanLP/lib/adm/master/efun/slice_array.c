mixed *slice_array(mixed *arr, int from, int to) {
    return arr[from..to];
}
