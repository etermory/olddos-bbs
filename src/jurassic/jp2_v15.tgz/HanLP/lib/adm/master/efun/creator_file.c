string creator_file(string str) {
   return (string)master()->creator_file(str);
}
