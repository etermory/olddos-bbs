string format_time(int tm, int verbose) {
    int days,hours,minutes,seconds;
    string str;

    str = "";

    if(!tm) return "0��";  

    days = tm / 86400;
    tm = tm % 86400;

    hours = tm / 3600;
    tm = tm % 3600;

    minutes = tm / 60;
    seconds = tm % 60;

    if(days)
	str += days + " �� ";

    if(hours)
	str += hours + " �ð� ";
 
    if(minutes)
	 str += minutes + " �� ";
 
    if(seconds)
	 str += seconds + " ��";
 
    if(str[strlen(str)-1] == ' ')  str = str[0..strlen(str)-2];
 
return str; }
 
#define MONTHS ({ "1��", "2��", "3��", "4��", "5��", \
		"6��", "7��", "8��", "9��", "10��", "11��", "12��" })

varargs string intl_date_stamp( int time_flag ) {
   int day, year;
   string tm, ret;
   mixed month;

   sscanf( ctime( time() ), "%*s %s %d %s 19%d",
	month, day, tm, year );

   month = 1 + member_array( month, MONTHS );

	if( month < 10 ) month = "0" + month;
	else month += "";

	ret = sprintf( "%d-%s-%d", year, month, day );

   if( time_flag) return sprintf( "%s %s", ret, tm );
   else return ret;	   
}

string use_time(int tm, int verbose) {
	int hours,minutes,seconds;
	string str;

	str = "";

	if(!tm) return "0��";
	hours = tm / 3600;
	tm = tm % 3600;
	minutes = tm / 60;
	seconds = tm % 60;
	if(hours) str += hours + "�ð� ";
	if(minutes) str += minutes + "��";
	return str;
}

