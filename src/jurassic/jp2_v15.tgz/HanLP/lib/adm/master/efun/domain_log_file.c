
void domain_log_file(string file, string message) {
    string *path, logpath;

    path = explode( file_name(previous_object()), "/" );
    if (path && path[0] == "d") {
        logpath = sprintf("/d/%s/logs/", path[1]);
        if (file_size(logpath) == -2) {
            seteuid(geteuid(previous_object()));
            logpath += file;

            if (file_size(logpath) != -2) {
                save_file(logpath, message);
            }
        }
    }
}
