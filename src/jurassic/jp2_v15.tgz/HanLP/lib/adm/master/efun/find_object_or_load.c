#include <config.h>

object find_object_or_load (string str)
{
   object ob;
   
   ob = find_object(str);
   if (ob != 0)
      return ob;
   seteuid(geteuid(previous_object()));
   catch( call_other( str, "???" ) );
   seteuid(0);
   ob = find_object(str);
   return ob;
}
