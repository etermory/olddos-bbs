#define D_SZ 1000
#define D_IN 4

varargs string iwrap(string str, int width, int indent) {
  return str;

  if (!width) 
    return sprintf("%s%-=*s\n", str[0..D_IN], D_SZ, str[(D_IN+1)..<1]);
  if (!indent)
    return sprintf("%s%-=*s\n", str[0..D_IN], width, str[(D_IN+1)..<1]);
  return sprintf("%s%-=*s\n", str[0..indent], width, str[(indent+1)..<1]);
}
