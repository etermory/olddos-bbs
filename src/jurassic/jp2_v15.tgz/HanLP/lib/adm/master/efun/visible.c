#include <uid.h>

varargs int visible( object detectee_obj, object detector_obj )
{
  string detector_euid;
  int detector_rank;
  int detectee_vis;

  if( !detectee_obj ) return 0;
  if( !detector_obj )
  {
    detector_euid = "TEMP";
  } else {
    if( detector_obj == detectee_obj ) return 1;
    detector_euid = geteuid( detector_obj );
  }

  if( detector_obj ) detector_rank = wizardp( detector_obj );
  if( adminp( detector_euid ) ) detector_rank = 2;

   if( objectp( detectee_obj ) )
  detectee_vis = detectee_obj->query( "����" );

  if( detectee_vis > detector_rank ) return 0;
  return 1;
}
