#define SZ 1000

varargs string wrap(string str, int width) {
	return str;

	if (!width) return sprintf("%-=*s", SZ, str);
	else return sprintf("%-=*s", width, str);
}
