#include <config.h>

varargs string temp_file( string base, object obj )
{
    if( !obj ) obj = this_player();
    return TMP_DIR + base + "-" + getoid( obj );
}
