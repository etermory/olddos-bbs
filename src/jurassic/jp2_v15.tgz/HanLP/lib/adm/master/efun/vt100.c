#include <ansi.h>

string inverse (string str)
{
    if (this_player()->query_env("vt100")) {
	return (REV + str + NOR);
    } else return str;
}

string blink (string str)
{
    if (this_player()->query_env("vt100")) {
	return (BLINK + str + NOR);
    } else return str;
}

string bold (string str)
{
    if (this_player()->query_env("vt100")) {
	return (BOLD + str + NOR);
    } else return str; 
}

string underscore (string str)
{
    if (this_player()->query_env("vt100")) {
	return (U + str + NOR);
    } else return str;
}

string clear_screen ()
{
    if (this_player()->query_env("vt100")) {
	return (CLR);
    }
    else return "";
}

string clear_line ()
{
    if (this_player()->query_env("vt100")) {
	return (CSI + "2K");
    }
    else return "";
}

string up_line ()
{
    if (this_player()->query_env("vt100")) {
	return (CSI + "A"); 
    }
    else return "";
}

string erase_line ()
{
    if (this_player()->query_env("vt100")) {
	return (clear_line() + CSI + "79D");
    }
    else return "\n";
}
