#include <config.h>

#ifdef __VERSION__

string version() { return __VERSION__; }
string arch() { return __ARCH__; }
#else
#ifdef MUDOS_VERSION

string version() { return MUDOS_VERSION; }
string arch() { return MUDOS_ARCH; }
#else
#ifdef VERSION

string version() { return VERSION; }
string arch() { return ARCH; }
#endif 
#endif 
#endif 

#ifdef MUD_NAME
string mud_name() { return MUD_NAME; }
#endif

#ifdef __PORT__
int mud_port() { return __PORT__; }
#else
#ifdef MUD_PORT
int mud_port() { return MUD_PORT; }
#endif 
#endif

string mudlib_name() 	{ return (MUDLIB_NAME); }
string mudlib_version()	{ return (MUDLIB_VERSION_NUMBER); }
