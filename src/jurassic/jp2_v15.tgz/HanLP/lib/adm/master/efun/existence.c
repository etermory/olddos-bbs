#include <config.h>
#include <mudlib.h>

int file_exists(string file)
{
	return (file_size(file) >= 0);
}

int directory_exists(string dirname)
{
	return (file_size(dirname) == -2);
}

int user_exists(string user)
{
	string file;

	if(!user) return 0;

	file = PDATA_FILE(user)+".o";

	if(file_size(file) > 0) {
		file = UDATA_FILE(user)+".o";
		if(file_size(file) > 0)
			return 1;
	}
	return 0;
}

int login_check(string name) {
	if( file_exists("/log/inuse/"+MUD_NAME+"/"+name) ) return -1;
	else if( file_exists("/log/inuse/jp1/"+name) ) return 1;
	else if( file_exists("/log/inuse/jp2/"+name) ) return 2;
	return 0;
}

int ip_check(string ip) {
	int ch=0;

	if( file_exists("/log/inuse/"+MUD_NAME+"/"+ip) ) {
		foreach( object ob in users() ) {
			if( ip != query_ip_number(ob) ) continue;
			if( (ch+1) >= 2 ) {
				return -1;
			}
			ch++;
		}
		return 0;
	}
	else if( file_exists("/log/inuse/jp1/"+ip) ) return 1;
	else if( file_exists("/log/inuse/jp2/"+ip) ) return 2;
	return 0;
}

void save_login_check(string name) {
	string file_name, dir;

	dir = "/log/inuse/"+MUD_NAME;
	if( !directory_exists(dir) ) {
		mkdir(dir);
	}
	file_name = dir+"/"+name;
	save_file(file_name,"");
	return;
}

void save_ip_check(string ip, string name) {
	string file_name, dir;

	dir = "/log/inuse/"+MUD_NAME;
	if( !directory_exists(dir) ) {
		mkdir(dir);
	}
	file_name = dir+"/"+ip;
	if( file_exists(file_name) ) rm(file_name);
	save_file(file_name,name);
	return;
}

void delete_ip_check(string ip) {
	string file_name, dir;

	dir = "/log/inuse/"+MUD_NAME;
	if( !directory_exists(dir) ) return;
	file_name = dir+"/"+ip;
	rm(file_name);
	return;
}

void delete_login_check(string name) {
	string file_name, dir;

	dir = "/log/inuse/"+MUD_NAME;
	if( !directory_exists(dir) ) return;
	file_name = dir+"/"+name;
	rm(file_name);
	return;
}
