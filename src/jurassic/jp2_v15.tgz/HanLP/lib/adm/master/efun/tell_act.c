varargs int tell_act(string str, object target, string special, int num)
{
    object owner, env;
    string name, tname, word, tword, eword;
    
    if(!str||str==""||!target) return 0;

    owner = this_player();
    env = environment( owner );
    name = han_iga(owner->query("�̸�"));
    tname = han_obj(target->query("�̸�"));
    if ( num ) {
	if( owner == target ) {
		word = "�����"+sprintf(str,"�����θ�")+( special? " [1;33m"+special+"[37;0m\n" : "\n");
    		eword = name+sprintf(str,"�ڽ���")+"\n";
		message("tell_act",word, owner);
		message("tell_act", eword, env, ({  owner }) );
		return 1;
	}
	word = "�����"+sprintf(str,tname)+( special? " [1m"+special+"[0m\n" : "\n");
	tword = name+sprintf(str,"�����")+( special? " [1m"+special+"[0m\n" : "\n");
    }
    else
    {
	word = "�����"+sprintf(str,tname)+( special? " [1;34m"+special+"[37;0m\n" : "\n");
	tword = name+sprintf(str,"�����")+( special? " [31m"+special+"[37;0m\n" : "\n");

    }
    eword = name+sprintf(str,tname)+"\n";
    message("tell_act",word, owner);
    message("tell_act",tword, target);
    message("tell_act", eword, env, ({  owner, target }) );
    return 1;
}
