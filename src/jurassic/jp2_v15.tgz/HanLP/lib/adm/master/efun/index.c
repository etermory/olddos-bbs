int index(mixed target, mixed *array, int offset)
{
   int i;
   
   if( !pointerp(array) || !intp(offset) ) return -1;
   array = array[offset..<1];
   if( (i = member_array(target, array)) < 0 ) return -1;
   else return i+offset;
}
