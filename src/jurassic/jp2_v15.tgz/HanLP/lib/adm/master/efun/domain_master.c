string domain_master( mixed domain )
{
  if( objectp( domain ) ) sscanf( file_name( domain ), "/d/%s/%*s", domain );
  if( !stringp( domain ) ) return 0;
  domain = "/d/" + domain + "/adm/d_master";
  if( file_size( domain + ".c" ) < 0 ) return 0;
  return domain;
}
