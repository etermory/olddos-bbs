#define	ERROR	'-'
#define	NOOPT	0

varargs mapping getopts (string arg, string options, string delim)
{
	int i, j, k, n, m;
	string param;
	int optlen = sizeof (options);
	string *args = arg ? explode (arg, delim = delim ? delim : " ") : 0;
	mapping res = ([ ]);

	n = sizeof (args);
	for (i=0; i < n; i++)
	{
		if (args[i][0] != '-')	// definitely no option
			break;
		m = sizeof (args[i]);
		for (j=1; j < m; j++)
		{
			k = strsrch (options, args[i][j]);
			if (k != -1 && options[k] != '-')
			{
				if (k+1 < optlen && options[k+1] == ':')
				{
					if (j+1 == m)
					{
						while (++i < n && ! sizeof (args[i]));	// strip off spaces
						if (i < n)
							param = args[i];
						else
						{
							--i;
							res[ERROR] = sprintf ("Option `%c' holds a parameter!\n", args[i][j]);
							args[i] = args[i][j..<1];
							j = m+1;
							break;	// long break
						}
					} else
						param = args[i][j+1..<1];
					res[options[k]] = param;
					break;	// short break
				} else
					res[options[k]] = 1;
			} else
			{
				if (args[i][j] != '-')
					res[ERROR] = sprintf ("Illegal option -- `%c'\nValid options are `%s'\n",
						args[i][j], implode (explode (replace_string (options, ":", ""), ""), "', `"));
				if (args[i][j] == '-' && ++j >= m)
					i++;
				else
					args[i] = args[i][j..<1];
				j = m+1;
				break;	// long break
			}
		}
		if (j > m)	// break the main loop, too
			break;
	}
	while (i < n && ! sizeof (args[i]))
		i++;
	if (i < n)
		res[NOOPT] = implode (args[i..n-1], delim);
	return (res);
}
