string format_string (string format, mixed *variables)
{
   string *tmp, ret;
   string tformat, ts;
   int i, max;
   int tsize, vsize; 
   
   tformat = "|" + format + "|%s";
   tmp = explode (tformat,"%s");
   if(tmp[0] == "|")
   		tmp[0] = "";
   	else
   		tmp[0] = extract(tmp[0],1);
   tsize = sizeof(tmp);
   if(tmp[tsize-1] == "|") {
  		tmp[tsize-1] = "";
  	}
  	else {
  	  ts = tmp[tsize-1];
  	  tmp[tsize-1] = extract(ts,0,strlen(ts)-2);
  	}
  
   if (!tmp || (tsize < 1) || !variables)
      return format;
   vsize = sizeof(variables);
   if (tsize < vsize) max = vsize;
   else max = tsize;
   ret = "";
   for (i = 0 ; i < max; i ++) {
      if(i < tsize)
      	ret +=  tmp[i];
      if(i < vsize)
      	ret += variables[i];
   }
   return ret;
}

string game_line(mixed num)
{
		string arg;

		if( !num )
				arg = "  [0;32m---------------------------[37;0;40m    JuDessic Park    [0;32m---------------------------[37;0;40m\n";

		else if (stringp( num ) ) {
				arg = sprintf("%|113s\n","[0;32m----------------[37;0;40m "+num+"[0;32m ----------------[37;0;40m");
		}
		else
				arg = "[11C[0;32m----------------------------------------------------------[37;0;40m\n";

		return arg;
}
