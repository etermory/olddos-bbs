int member_group(string user, string group) {
	return (int)master()->query_member_group(user, group);
}
