varargs string resolv_path(string cur, string newvalue) {

    string *path, *tmp;
    int pos, i;

    if (cur == "������")
	if (this_player())
	    cur = (string) this_player()->query("������");
	else
	    cur = "";
    if (!cur || cur == "")
	cur = "/";
    if (!newvalue || newvalue == "" || newvalue == ".")
	return cur;
    if (this_player() && (newvalue == "here" || newvalue == "env"))
	if (environment(this_player()))
	    return file_name(environment(this_player())) + ".c";
	else
	    return "NONAME.c";
    if (newvalue == "/")
	return newvalue;

    if (cur == "/" || newvalue[0] == '/')
	path = ({ });
    else
	path = explode(cur, "/");
    tmp = explode(newvalue, "/");
    if(!tmp || !sizeof(tmp)) return "/";
    if (tmp[0][0] == '~') return "/text/doc/";
    pos = sizeof(path);
    for(i = 0; i < sizeof(tmp); i++)
    {
	if (!tmp[i] || tmp[i] == "" || tmp[i] == ".")
	    continue;
	if (tmp[i] == "..")
	{
	    pos--;
	    if (pos<0)
		pos = 0;
	    continue;
	}
	if (pos >= sizeof(path))
	    path += ({ tmp[i] });
	else
	    path[pos] = tmp[i];
	pos++;
    }
    return ( "/" + implode(path[0..pos - 1], "/" ));
}
