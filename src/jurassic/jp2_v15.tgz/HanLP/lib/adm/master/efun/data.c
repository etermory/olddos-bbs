#include <config.h>
#include <uid.h>

string data_dir(object obj) {
   return DATA_DIR + base_name(obj);
}

string data_file(object obj) {
   return data_dir(obj) + "/" + (geteuid(obj) ? geteuid(obj) : getuid(obj));
}

varargs string user_data_dir(object obj, string name) {
   if (!name) name = (geteuid(obj));
   if (!name) return "" ;
   return UDATA_DIR(name);
}

varargs string user_data_file(object obj, string name) {
   name = name ? name : geteuid(obj);
   return UDATA_FILE(name);
}

void assure_user_save_dir(object user) {
	string dir, path, *parts;
	int j;
        if (previous_object() != user) return;
	path = user_data_dir(user);
        if (file_size(path) == -1) {
                seteuid(ROOT_UID);
	        parts = explode(path, "/");
		dir = "";
		for (j = 0; j < sizeof(parts); j++) {
                	dir += parts[j];
                	mkdir(dir);
                	dir += "/";
        	}
        }
	if (file_size(path) == -1)
		write("����� ������ ������ ���丮�� ã�� �� �����ϴ�.\n");
}

void assure_save_dir(object user) {
        string dir, path, *parts;
        int j;
        if (previous_object() != user) return;
        path = data_dir(user);
        if (file_size(path) == -1) {
                seteuid(ROOT_UID);
                parts = explode(path, "/");
                dir = "";
                for (j = 0; j < sizeof(parts); j++) {
                        dir += parts[j];
                        mkdir(dir);
                        dir += "/";
                }
        }
}
