#define ADMINACCESS "adminaccess"

int adminp( mixed ob_or_str ) {
    if ((stringp(ob_or_str) &&
          (int)master()->query_member_group(ob_or_str, ADMINACCESS)) ||
        (objectp(ob_or_str) &&
          (int)master()->query_member_group(geteuid(ob_or_str), ADMINACCESS)))
        return 1;
    return 0;
}
