varargs object get_object( string str, object player )
{
  object what;
  mixed tmp;

  seteuid( geteuid( previous_object() ) );

  if( !str ) return 0;
  if( !player || !living( player ) ) player = this_player();
  if( sscanf( str, "@%s", tmp )         &&
    ( tmp = get_object( tmp, player ) ) &&
    ( what = environment( tmp )       )    )
    return what;
  if( player )
  {
    if( str == "��" ) return player;
    if( what = present( str, player ) ) return what;
    if( what = environment( player ) )
    {
      if (str == "����" || str == "�̰�" || str == "��")
        return what;
      if( what = present( str, what ) ) return what;
    }
  }
 
  if( what = present( str, previous_object() ) )  return what;
  if( what = find_player( str ) ) return what;
  if( what = find_living( str ) ) return what;

  if( player )
  {
    str = resolv_path( (string)player-> query( "cwd" ), str );
  }
 
  what = find_object(str);
  if (!what && (file_size(str) >= 0 || file_size(str + ".c") >= 0)) {
    catch( call_other( str, "???" ) );
 
    what = find_object( str );
  }

  return what;
}

varargs mixed get_objects( string str, object player, int no_arr )
{
  mixed base, tmp, ret;
  object what;
  int i, s;

  seteuid( geteuid( previous_object() ) );

  if( !str ) return 0;
  s = strlen( str );
  i = s;
  while (i-- && (str[i] != ':')) ;
  if( ( i > 0 ) && ( i < ( s - 1 ) ) )
  {
    base = get_objects( str[0..(i-1)], player );
    str = str[(i+1)..s];
    if( !base ) return 0;
    if( !pointerp( base ) ) base = ({ base });
    s = sizeof( base );
    ret = ({ });
    if( str == "e" )
    {
      while( s-- )
        if( tmp = environment( base[s] ) )
          ret += ({ tmp });
    } else if( str == "i" ) {
      while( s-- )
        if( tmp = all_inventory( base[s] ) )
          ret += ( pointerp( tmp ) ? tmp : ({ tmp }) );
    } else if( str == "d" ) {
      while( s-- )
        if( tmp = deep_inventory( base[s] ) )
          ret += ( pointerp( tmp ) ? tmp : ({ tmp }) );
    } else if( sscanf( str, "%d", i ) ) {
      if( ( i > -1 ) && ( i < s ) ) return base[i];
      else return 0;
    } else if( str == "c" ) {
      while( s-- )
	if(tmp = children(base_name(base[s])))
	  ret += tmp;
    } else if( str == "s" ) {
      while( s-- )
	for(tmp=shadow(base[s],0);tmp;tmp=shadow(tmp,0))
	  ret += ({ tmp });
    } else if( strlen(str) && str[0] == '>' ) {
      str=extract(str,1);
      while( s-- )
	if(objectp(tmp=(mixed)call_other(base[s],str)))
	  ret += ({ tmp });
	else if( pointerp(tmp) && sizeof(tmp) && objectp(tmp[0]) )
	  ret += tmp;
    } else {
      while( s-- )
        if( what = present( str, base[s] ) )
          return what;
      return 0;
    }
    switch( sizeof( ret ) )
    {
      case 0: return 0;
      case 1: return ret[0];
    }
    return( no_arr ? ret[0] : ret );
  }
  if( str == "users" )
  {
    ret = users();
    if( !no_arr ) return ret;
    if( sizeof( ret ) ) return ret[0];
    return 0;
  }
  return get_object( str, player );
}
