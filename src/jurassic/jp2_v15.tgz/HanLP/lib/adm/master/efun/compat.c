#include <config.h>
#include <uid.h>

#define CAT_LINES_DEFAULT 24
#define CAT_LINES_MAXIMUM 40
#define MAX_LOG_SIZE 200000

varargs int cat( string path, int start, int num )
{
    string text;
    int trun;

    if( !path ) return 0; 
    if( !start ) start = 0;
    if( !num ) num = CAT_LINES_DEFAULT;
    if( num > CAT_LINES_MAXIMUM )
    {
        num = CAT_LINES_MAXIMUM;
        trun = 1;
    }
    seteuid( geteuid( previous_object() ) );
    if( text = read_file( path, start, num ) )
    {
        if( trun && ( strlen( text ) < file_size( path ) ) )
            text += "***TRUNCATED***\n";
        message( "cat", text, this_player() );
        return 1; 
    }
    return 0; 
}

varargs string extract( string str, int from, int to )
{
    if( !stringp( str ) ) return ""; 
    if( nullp( from ) ) return str;
    if( nullp( to ) ) to = strlen( str );
    return str[from..to];
}

object first_inventory( mixed ob )
{
    object *inv;

    if( stringp( ob ) )
        ob = find_object( ob );
    if( !objectp( ob ) ) return 0;
    if( sizeof( inv = all_inventory( ob ) ) )
        return inv[0];
    return 0;
}

object next_inventory( object ob )
{
    object env, *inv;
    int ind;

    if( !objectp( ob ) ) return 0; 
    if( !objectp( env = environment( ob ) ) ) return 0; 
    if( sizeof( inv = all_inventory( env ) ) ==
      ( ind = 1 + member_array( ob, inv  ) )   )
        return 0; 
    return inv[ind]; 
}

object shadowp( object ob ) { return query_shadowing( ob ); } 

void log_file( string file, string text )
{
    if( !stringp( file ) || !stringp( text ) ) return; 
    if( -1 != strsrch( file, ".." ) ) return; 
    if (previous_object()) {
	if (base_name( previous_object() ) ==USER_OB ||
            base_name( previous_object() ) == CONNECTION 
	    ) {
	    seteuid(ROOT_UID) ;
	} else {
	    seteuid(geteuid(previous_object())) ;
	}
   }
    if(file_size(LOG_DIR) == -2) {
	mkdir(LOG_DIR);
	mkdir(LOG_DIR+"/adm");
	mkdir(LOG_DIR+"/system");
	mkdir(LOG_DIR+"/inuse");
	mkdir(LOG_DIR+"/driver");
    }
    file = LOG_DIR + file; 
    if( file_size( file ) > MAX_LOG_SIZE )
        rename( file, file + ".old" );
    save_file( file, text );
}
