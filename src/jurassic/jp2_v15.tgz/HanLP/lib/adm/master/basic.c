#include <uid.h>
#include <config.h>
#include <daemons.h>
#include <commands.h>
#include <domains.h>
#include <logs.h>
#include <origin.h>

inherit "/adm/master/access";

static int access_loaded = 0;

void preload( string file );

void create()
{
	if(origin() == ORIGIN_DRIVER)
		call_out("free_objects", 3600);
}

static void free_objects()
{
	call_out("free_objects", 3600);
	efun::reclaim_objects();
}

static void flag( string str )
{
	string file;
	mixed arg;

	if( sscanf( str, "for %d", arg ) == 1 )
	{
		int i;
		for( i = 0; i < arg; i++ ) { }
		return;
	}
	if( sscanf( str, "echo %s", arg ) == 1 )
	{
		write( arg + "\n" );
		return;
	}
	if( sscanf( str, "call %s %s", file, arg ) == 2 )
	{
		arg = (string)call_other( file, arg );
		write( "Got " + arg + " back.\n" );
		return;
	}
	write( "master: Unknown flag " + str + "\n" );
}

object connect()
{
	object login_ob;
	mixed err;

	err = catch( login_ob = clone_object( CONNECTION ) );
	if( err )
	{
		receive( "It looks like someone is working on the player object.\n" );
		receive( err );
		destruct( this_object() );
	}
	return login_ob;
}

static void crash( string error, object command_giver, object current_object )
{
	string crashes;

	crashes = "system/crashes";

	log_file(crashes, mud_name() + " CRASHED on: " + ctime( time() ) +
			" ����: " + error + "\n" );
	shout( "\n\n* �ý����� ��û�� ���� ������ ����˴ϴ�.\n" );

	if( command_giver ) log_file(crashes,
			"this_player: " + file_name( command_giver ) + "\n" );
	if( current_object )log_file(crashes,
			"this_object: " + file_name( current_object ) + "\n" );

	save_file( TMP_DIR "MudOS_crash", "abcdefg" );
	if( file_size( TMP_DIR "MudOS_crash" ) )
	{
		rm( TMP_DIR "MudOS_crash" );
		SHUTDOWN_D->do_shutdown( 0 );
	}
}

int valid_write( string file, mixed user, string func )
{
	return 1;
}

int valid_read( string file, mixed user, string func )
{
	return 1;
}

int valid_save_binary( string filename )
{
	string creator;
	creator = creator_file( filename );
	if( creator == ROOT_UID || creator == BACKBONE_UID ) return 1;
	return 0;
}

int valid_seteuid( object ob, string str )
{
	if( getuid( ob ) == ROOT_UID ) return 1;
	if( file_name( ob ) == SIMUL_EFUN_OB ) return 1;
	if( str == "TEMP" ) return 1;
	if( str == "News" && getuid( ob ) == BACKBONE_UID ) return 1;
	if( getuid( ob ) == str ) return 1;
	if( creator_file( file_name( ob ) ) == str ) return 1;
	return 0;
}

nomask int valid_shadow( object ob )
{
	if( creator_file( file_name( ob ) ) == ROOT_UID ) return 0;
	if( file_name( ob ) == SIMUL_EFUN_OB ) return 0;
	if(adminp(ob)) return 0;
	if( function_exists( "query", previous_object() ) ) return 0;
	if( function_exists( "query_link", previous_object() ) ) return 0;
	return !ob-> query_prevent_shadow( previous_object() );
}

string *epilog( int load_empty )
{
	string *items;

	items = update_file( CONFIG_DIR + "preload" );
	return items;
}

void preload( string file )
{
	string err;

	if (origin() != ORIGIN_DRIVER)  return;
	write( "Preloading : " + file + "..." );
	err = catch( call_other( file, "??" ) );
	if( err != 0 )
	{
		write( "\nGot error " + err + " when loading " + file + "\n" );
	} else {
		write( "\n" );
	}
}

void log_error( string file, string message ) {

	if (file[0] != '/') file = "/" + file;
	save_file(LOG_DIR + "log", message);
}

int save_ed_setup( object who, int code )
{
	if( !intp( code ) )
		return 0;
	return (int) this_player()-> set("ed_settings", code);
}

void destruct_env_of( object ob)
{
	if( !interactive( ob ) )
	{
		ob-> remove();
		if( ob ) destruct( ob );
		return;
	}
	tell_object( ob,
			" * ����� �ִ� ���� ��������ϴ�.\n"+
			" * ����� ������� ���� ���ϴ�.\n"
			); 
	ob-> move( VOID );
}

string get_root_uid() { return ROOT_UID;  }
string get_bb_uid() { return BACKBONE_UID;  }

string creator_file( string str )
{
	string *path;

	if( str[0] != '/' ) str = "/" + str;

	path = explode( str, "/" ) - ({ "" });
	if( !path ) return 0;
	if( path[0] == 0 )
	{
		log_file( "creator_file",
				"no first element of array, str = " + str + "\n" );
		path = path[1..<1];
	}
	switch( path[0] )
	{
		case "adm":
			if( str == SIMUL_EFUN_OB ) return "NONAME";
			else return ROOT_UID;
			break;
			case "cmds": return ROOT_UID; break;
			case "std":
				return "NONAME"; break;
			case "obj": return BACKBONE_UID; break;
			case "u":
				if (sizeof(path) < 3) return "Anonymous";
			if( (path[2]!=ROOT_UID)&&(path[2]!=BACKBONE_UID)) {
				if (sizeof(path) >= 4 && path[2] && path[3])
					return path[2]; 
				break; }
				case "d":
					if (sizeof(path) < 3) return "Anonymous";
				if( (path[1]!=ROOT_UID)&&(path[2]!=BACKBONE_UID)) {
					if (sizeof(path) >= 3 && path[2])
						return path[1];
					break; }
		default:
					return "Anonymous";
					break;
	}
	return 0;
}

string domain_file( string filename )
{
	string *path;

	path = explode( filename, "/" );
	if( !path ) return "NONAME";

	switch( path[0] )
	{
		case "adm": return ROOT_UID; break;
		case "cmds": return ROOT_UID; break;
		case "std": return "NONAME"; break;
		case "obj": return BACKBONE_UID; break;
		case "u": return "User"; break;
		case "d":
			if (sizeof(path) > 1 && path[1] != "*")
				return path[1];
		default: return "NONAME"; break;
	}

}

int valid_domain( string dom )
{
	if( member_array( dom, DOMAIN_DIRS ) !=  - 1 )
		return 1;
	return 0;
}

int valid_override( string bfile, string name, string file )
{

	if (file[0] != '/') file = "/" + file;
	sscanf(file, "%s.c", file);
	if ( (file == SIMUL_EFUN_OB) || (file == "/adm/simul_efun/overrides") ) return 1;
	if( function_exists( name, find_object( SIMUL_EFUN_OB ) ) ) return 0;
	return 1;
}

int valid_link( string original, string reference )
{
	return 0;
}

void make_data_dir()
{
	string *parts, dir;
	string path;
	int j;

	path = data_dir( previous_object() );
	parts = explode( path, "/" );
	dir = "";
	for( j = 0; j < sizeof( parts ); j++ )
	{
		dir += parts[j];
		mkdir( dir );
		dir += "/";
	}
}

int different(string fn, string pr) {
	int tmp;

	sscanf(fn, "%s#%d", fn, tmp);
	fn += ".c";
	return (fn != pr) && (fn != ("/" + pr));
}

string trace_line(object obj, string prog, string file, int line) {
	string ret;
	string objfn = obj ? file_name(obj) : "<none>";

	ret = objfn;
	if (different(objfn, prog))
		ret += sprintf(" (%s)", prog);

	if (file != prog)
		ret += sprintf(" at %s:%d\n", file, line);
	else
		ret += sprintf(" at line %d\n", line);

	return ret;
}

varargs string standard_trace(mapping mp, int flag) {
	string ret;
	mapping *trace;
	int i, n;

	ret = mp["error"] + "Object: " +
		trace_line(
				mp["������Ʈ"], mp["program"], mp["file"], mp["line"]) + "\n";

	trace = mp["trace"];

	for (i = 0, n = sizeof(trace); i < n; i++) {
		if (flag)
			ret += sprintf("#%d: ", i);

		ret += sprintf("'%s' at %s",
				trace[i]["function"],
				trace_line(trace[i]["������Ʈ"],
					trace[i]["program"],
					trace[i]["file"],
					trace[i]["line"])
				);
	}
	return ret;
}

string error_handler(mapping mp, int caught) {
	string ret;

	ret = "---\n"+ ctime(time())+"\n"+ standard_trace(mp);
	save_file("/log/runtime",ret);

	if (this_player(1)) {
		message("error",sprintf("%s",mp["error"]),this_player(1));
		this_player(1)->set_error(mp);
	} else if (this_player()) {
		message("error",sprintf("%s",mp["error"]),this_player());
		this_player()->set_error(mp);
	}

	return 0;
}

int valid_object(object ob) {

	string foo;
	if (!sscanf(file_name(ob), "%s#%*d", foo)) foo = file_name(ob);

	if (foo[0..4] == "/tmp/")  return 0;
	if (strsrch(foo,"/.") != -1 )  return 0;
	return 1;
}

int valid_bind(object binder, object old_owner, object new_ownwe) {
	return 0;
}
